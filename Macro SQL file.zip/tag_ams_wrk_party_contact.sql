CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_CountryCode('Country_Code')}},
	{{validate_01YN('Chng_Ind')}},
	{{validate_01YN('Permanent_Add_Ind')}},
	{{validate_HKPhoneAreaCode('Phone_Area_Code')}},
	{{validate_PhoneTypeCode('Phone_Type_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__CountryCode_valid_Country_Code',__01YN_valid_Chng_Ind',__01YN_valid_Permanent_Add_Ind',__HKPhoneAreaCode_valid_Phone_Area_Code',__PhoneTypeCode_valid_Phone_Type_Desc']) }}
FROM CTE_3)