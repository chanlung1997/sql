CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('new_issue_country_code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_new_issue_country_code']) }}
FROM CTE_3)