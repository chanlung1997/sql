CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Instr_End_Dte')}},
	{{validate_NoFutureDate('Instr_Modify_User_Id')}},
	{{validate_NoFutureDate('Instr_Create_Dte')}},
	{{validate_NoFutureDate('Instr_Modify_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Instr_End_Dte',__NoFutureDate_valid_Instr_Modify_User_Id',__NoFutureDate_valid_Instr_Create_Dte',__NoFutureDate_valid_Instr_Modify_Dte']) }}
FROM CTE_3)