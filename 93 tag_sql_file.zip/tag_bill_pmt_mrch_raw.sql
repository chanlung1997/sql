CREATE  OR  REPLACE  TABLE  `bqd_015_raw.tag_bill_pmt_mrch_raw`  (
Mrch_Id  STRING(5),
Mrch_Name  STRING(50),
Mrch_Categ  STRING(30),
__batch_date  TIMESTAMP,   
__load_date  TIMESTAMP,   
__file_name  STRING,   
__load_type  STRING,   
__sys_code  STRING,   
__row_number  STRING 
);
