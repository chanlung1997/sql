CTE_3 AS (
	SELECT
	*,
	{{validate_Acpt_1148_1005_9999('Master_Sts_Update_Centre_Id')}},
	{{validate_NoFutureDate('Create_Dte')}},
	{{validate_NoFutureDate('Curr_Anl_Enhance_Rev_Comp_dte')}},
	{{validate_NoFutureDate('Curr_Anl_RM_Enq_Comp_Dte')}},
	{{validate_NoFutureDate('Curr_Anl_RM_Enq_Dte')}},
	{{validate_NoFutureDate('Current_Anl_HV_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('Master_Sts_Update_Dte')}},
	{{validate_NoFutureDate('Pre_Exist_Cust_Sts_Update_Dte')}},
	{{validate_NoFutureDate('Pre_Existing_HV_Dte')}},
	{{validate_NoFutureDate('Self_Cert_Dte')}},
	{{validate_NoFutureDate('Trx_Dte')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_NoFutureDate('Last_Anl_Enhance_Rev_Comp_Dte')}},
	{{validate_NoFutureDate('Last_Anl_HV_Dte')}},
	{{validate_NoFutureDate('Last_Anl_RM_Enq_Comp_Dte')}},
	{{validate_NoFutureDate('Last_Anl_RM_Enq_Dte')}},
	{{validate_NoFutureDate('Last_Update_Dte')}},
	{{validate_01YN('HK_Tax_Resident_Ind')}},
	{{validate_NoFutureDate('Self_Cert_Last_Update_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Acpt_1148_1005_9999_valid_Master_Sts_Update_Centre_Id',__NoFutureDate_valid_Create_Dte',__NoFutureDate_valid_Curr_Anl_Enhance_Rev_Comp_dte',__NoFutureDate_valid_Curr_Anl_RM_Enq_Comp_Dte',__NoFutureDate_valid_Curr_Anl_RM_Enq_Dte',__NoFutureDate_valid_Current_Anl_HV_Dte',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_Master_Sts_Update_Dte',__NoFutureDate_valid_Pre_Exist_Cust_Sts_Update_Dte',__NoFutureDate_valid_Pre_Existing_HV_Dte',__NoFutureDate_valid_Self_Cert_Dte',__NoFutureDate_valid_Trx_Dte',__CountryCode_valid_Issue_Country_Code',__NoFutureDate_valid_Last_Anl_Enhance_Rev_Comp_Dte',__NoFutureDate_valid_Last_Anl_HV_Dte',__NoFutureDate_valid_Last_Anl_RM_Enq_Comp_Dte',__NoFutureDate_valid_Last_Anl_RM_Enq_Dte',__NoFutureDate_valid_Last_Update_Dte',__01YN_valid_HK_Tax_Resident_Ind',__NoFutureDate_valid_Self_Cert_Last_Update_Dte']) }}
FROM CTE_3)