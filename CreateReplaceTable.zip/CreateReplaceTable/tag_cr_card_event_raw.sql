CREATE  OR  REPLACE  TABLE  `bqd_015_raw.tag_cr_card_event_raw`  (
Event_Id  STRING(23),
Mcc_Code  STRING(4),
Mrch_Nbr  STRING(9),
Mrch_Org_Nbr  STRING(3),
__row_number  STRING,   
__sys_code  STRING,   
__file_name  STRING,   
__batch_date  TIMESTAMP,   
__load_date  TIMESTAMP,   
__load_type  STRING 
);
