CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Ecg_Chass_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Ecg_Chass_Ind']) }}
FROM CTE_3)