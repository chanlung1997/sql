CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Recv_Country_Code')}},
	{{validate_CountryCode('Trans_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Recv_Country_Code',__CountryCode_valid_Trans_Country_Code']) }}
FROM CTE_3)