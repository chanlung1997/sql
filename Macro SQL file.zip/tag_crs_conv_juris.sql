CTE_3 AS (
	SELECT
	*,
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_CountryCode('Juris_Country_Code')}},
	{{validate_01YN('Add_POO_Ind')}},
	{{validate_01YN('Ctrl_Person_Sole_Propr_Ind')}},
	{{validate_01YN('PASA_Ind')}},
	{{validate_01YN('Place_Of_Origin_Ind')}},
	{{validate_01YN('Sole_Props_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code',__CountryCode_valid_Juris_Country_Code',__01YN_valid_Add_POO_Ind',__01YN_valid_Ctrl_Person_Sole_Propr_Ind',__01YN_valid_PASA_Ind',__01YN_valid_Place_Of_Origin_Ind',__01YN_valid_Sole_Props_Ind']) }}
FROM CTE_3)