CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Choice_Fund_Eff_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Choice_Fund_Eff_Dte']) }}
FROM CTE_3)