CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Actvn_Dte')}},
	{{validate_NoFutureDate('Card_Issue_Dte')}},
	{{validate_NoFutureDate('Cash_Voucher_Last_Update_Dte')}},
	{{validate_Future_Date('Anl_Fee_Expiry_Dte')}},
	{{validate_Future_Date('Expiry_Dte')}},
	{{validate_NoFutureDate('Card_Retain_Dte')}},
	{{validate_NoFutureDate('Pin_Issue_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Actvn_Dte',__NoFutureDate_valid_Card_Issue_Dte',__NoFutureDate_valid_Cash_Voucher_Last_Update_Dte',__Future_Date_valid_Anl_Fee_Expiry_Dte',__Future_Date_valid_Expiry_Dte',__NoFutureDate_valid_Card_Retain_Dte',__NoFutureDate_valid_Pin_Issue_Dte']) }}
FROM CTE_3)