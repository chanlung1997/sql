CTE_3 AS (
	SELECT
	*,
	{{validate_Acpt_len_5_9_10_12to14_15_17_20('Acct_Nbr')}},
	{{validate_CountryCode('IP_Country_Code')}},
	{{validate_NoFutureDate('Start_Event_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Acpt_len_5_9_10_12to14_15_17_20_valid_Acct_Nbr',__CountryCode_valid_IP_Country_Code',__NoFutureDate_valid_Start_Event_Dte']) }}
FROM CTE_3)