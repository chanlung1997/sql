CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('dep_bank_country_code')}},
	{{validate_NoFutureDate('appl_dte')}},
	{{validate_CountryCode('inter_bank_country_code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_dep_bank_country_code',__NoFutureDate_valid_appl_dte',__CountryCode_valid_inter_bank_country_code']) }}
FROM CTE_3)