CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('First_Impair_Dte')}},
	{{validate_NoFutureDate('Impair_Dte')}},
	{{validate_NoFutureDate('Val_Dte')}},
	{{validate_NoFutureDate('Tran_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_First_Impair_Dte',__NoFutureDate_valid_Impair_Dte',__NoFutureDate_valid_Val_Dte',__NoFutureDate_valid_Tran_Dte']) }}
FROM CTE_3)