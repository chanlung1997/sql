CREATE  OR  REPLACE  TABLE  `bqd_015_raw.tag_prod_categ_raw`  (
Prod_Categ_Code  STRING(6),
Prod_Categ_Desc  STRING(30),
Prod_Subtype_Code  STRING(6),
__row_number  STRING,   
__sys_code  STRING,   
__file_name  STRING,   
__batch_date  TIMESTAMP,   
__load_date  TIMESTAMP,   
__load_type  STRING 
);
