CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Add_Country_Code')}},
	{{validate_NoFutureDate('Birth_Dte')}},
	{{validate_CountryCode('Res_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Add_Country_Code',__NoFutureDate_valid_Birth_Dte',__CountryCode_valid_Res_Country_Code']) }}
FROM CTE_3)