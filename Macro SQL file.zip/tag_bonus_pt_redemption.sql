CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_10('Order_Nbr')}},
	{{validate_NoFutureDate('Redeem_Conf_Dte')}},
	{{validate_NoFutureDate('Redemption_Dte')}},
	{{validate_01YN('Redeem_Conf_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_10_valid_Order_Nbr',__NoFutureDate_valid_Redeem_Conf_Dte',__NoFutureDate_valid_Redemption_Dte',__01YN_valid_Redeem_Conf_Ind']) }}
FROM CTE_3)