CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Aprov_Dte')}},
	{{validate_Future_Date('Expect_Cmple_Dte')}},
	{{validate_NoFutureDate('Acpt_Dte')}},
	{{validate_NoFutureDate('Appl_Dte')}},
	{{validate_NoFutureDate('Last_Upd_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Aprov_Dte',__Future_Date_valid_Expect_Cmple_Dte',__NoFutureDate_valid_Acpt_Dte',__NoFutureDate_valid_Appl_Dte',__NoFutureDate_valid_Last_Upd_Dte']) }}
FROM CTE_3)