CTE_3 AS (
	SELECT
	*,
	{{validate_Acct_Rel_Type_Desc('Acct_Rel_Type_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__Acct_Rel_Type_Desc_valid_Acct_Rel_Type_Desc']) }}
FROM CTE_3)