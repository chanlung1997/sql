CTE_3 AS (
	SELECT
	*,
	{{validate_MaritalStatus('Marital_Status')}}
FROM CTE_2
),
{{ full_valid_flag([__MaritalStatus_valid_Marital_Status']) }}
FROM CTE_3)