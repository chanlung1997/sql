CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_12('Contrib_Batch_Nbr')}},
	{{validate_NoFutureDate('Confirm_Dte')}},
	{{validate_Future_Date('Cover_Fr_Dte')}},
	{{validate_Future_Date('Cover_To_Dte')}},
	{{validate_NoFutureDate('Fund_Price_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_12_valid_Contrib_Batch_Nbr',__NoFutureDate_valid_Confirm_Dte',__Future_Date_valid_Cover_Fr_Dte',__Future_Date_valid_Cover_To_Dte',__NoFutureDate_valid_Fund_Price_Dte']) }}
FROM CTE_3)