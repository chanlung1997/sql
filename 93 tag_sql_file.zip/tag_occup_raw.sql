CREATE  OR  REPLACE  TABLE  `bqd_015_raw.tag_occup_raw`  (
Occup_Code  STRING(20),
Occup_Desc  STRING(100),
__batch_date  TIMESTAMP,   
__load_date  TIMESTAMP,   
__file_name  STRING,   
__load_type  STRING,   
__sys_code  STRING,   
__row_number  STRING 
);
