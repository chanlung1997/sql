CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Event_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Event_Country_Code']) }}
FROM CTE_3)