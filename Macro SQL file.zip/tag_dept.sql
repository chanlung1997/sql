CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Dept_Close_Dte')}},
	{{validate_NoFutureDate('Dept_Open_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Dept_Close_Dte',__NoFutureDate_valid_Dept_Open_Dte']) }}
FROM CTE_3)