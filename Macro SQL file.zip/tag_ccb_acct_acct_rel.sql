CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Rel_End_Dte')}},
	{{validate_01YN('Bills_Acct_Ind')}},
	{{validate_01YN('Mas_Acct_Ind')}},
	{{validate_NoFutureDate('Rel_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Rel_End_Dte',__01YN_valid_Bills_Acct_Ind',__01YN_valid_Mas_Acct_Ind',__NoFutureDate_valid_Rel_Start_Dte']) }}
FROM CTE_3)