CTE_3 AS (
	SELECT
	*,
	{{validate_Acpt_0_1_2('US_Phone_Nbr_Ind')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_IndustryCode('Industry_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_NoFutureDate('Recalcitrant_Dte')}},
	{{validate_CountryCode('US_Issue_Country_Code')}},
	{{validate_CountryCode('US_Issue_Country_Code_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__Acpt_0_1_2_valid_US_Phone_Nbr_Ind',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__IndustryCode_valid_Industry_Code',__CountryCode_valid_Issue_Country_Code',__NoFutureDate_valid_Recalcitrant_Dte',__CountryCode_valid_US_Issue_Country_Code',__CountryCode_valid_US_Issue_Country_Code_Ind']) }}
FROM CTE_3)