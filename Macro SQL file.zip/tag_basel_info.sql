CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Non_Retail_Next_Review_Dte')}},
	{{validate_Future_Date('Retail_Ovr_Dte')}},
	{{validate_Future_Date('Retail_Ovr_Recal_Dte')}},
	{{validate_Future_Date('Retail_Recal_Dte')}},
	{{validate_NoFutureDate('Corp_Expos_Last_Rate_Dte')}},
	{{validate_NoFutureDate('Special_Lending_Last_Rate_Dte')}},
	{{validate_NoFutureDate('Std_Approach_Last_Rate_Dte')}},
	{{validate_01YN('Retail_Override_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Non_Retail_Next_Review_Dte',__Future_Date_valid_Retail_Ovr_Dte',__Future_Date_valid_Retail_Ovr_Recal_Dte',__Future_Date_valid_Retail_Recal_Dte',__NoFutureDate_valid_Corp_Expos_Last_Rate_Dte',__NoFutureDate_valid_Special_Lending_Last_Rate_Dte',__NoFutureDate_valid_Std_Approach_Last_Rate_Dte',__01YN_valid_Retail_Override_Ind']) }}
FROM CTE_3)