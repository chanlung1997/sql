CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Od_Int_Rate_Normal_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Od_Int_Rate_Normal_Ind']) }}
FROM CTE_3)