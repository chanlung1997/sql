CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_14('Cara_Ref_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Acpt_len_6to16('Irn_Ref_Nbr')}},
	{{validate_Next_Assess_Type('Next_Assess_Type')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_14_valid_Cara_Ref_Nbr',__NoFutureDate_valid_Batch_Dte',__Acpt_len_6to16_valid_Irn_Ref_Nbr',__Next_Assess_Type_valid_Next_Assess_Type',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code']) }}
FROM CTE_3)