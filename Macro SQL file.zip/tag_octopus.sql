CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Appl_Dte')}},
	{{validate_NoFutureDate('Octopus_Card_Status_Dte')}},
	{{validate_NoFutureDate('Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Appl_Dte',__NoFutureDate_valid_Octopus_Card_Status_Dte',__NoFutureDate_valid_Start_Dte']) }}
FROM CTE_3)