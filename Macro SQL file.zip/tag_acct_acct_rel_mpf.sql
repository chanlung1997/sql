CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('rel_end_dte')}},
	{{validate_NoFutureDate('rel_start_dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_rel_end_dte',__NoFutureDate_valid_rel_start_dte']) }}
FROM CTE_3)