CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Capped_Rate_Flag')}},
	{{validate_01YN('Compare_Rate_Flag')}},
	{{validate_01YN('IRS_Hedged_Flag')}},
	{{validate_01YN('Revolving_Flag')}},
	{{validate_01YNYesNo('Scheduled_PPL_Repay_Flag')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Capped_Rate_Flag',__01YN_valid_Compare_Rate_Flag',__01YN_valid_IRS_Hedged_Flag',__01YN_valid_Revolving_Flag',__01YNYesNo_valid_Scheduled_PPL_Repay_Flag']) }}
FROM CTE_3)