CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Rel_End_Dte')}},
	{{validate_NoFutureDate('Rel_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Rel_End_Dte',__NoFutureDate_valid_Rel_Start_Dte']) }}
FROM CTE_3)