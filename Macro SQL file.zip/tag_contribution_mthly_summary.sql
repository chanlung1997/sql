CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Choice_Plan_Eff_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Choice_Plan_Eff_Dte']) }}
FROM CTE_3)