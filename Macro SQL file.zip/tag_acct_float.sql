CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Expiry_Dte')}},
	{{validate_NoFutureDate('Last_Update_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Expiry_Dte',__NoFutureDate_valid_Last_Update_Dte']) }}
FROM CTE_3)