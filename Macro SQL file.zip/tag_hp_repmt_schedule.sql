CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Trx_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Trx_Dte']) }}
FROM CTE_3)