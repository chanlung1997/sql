CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_Future_Date('Relevant_Indv_End_Dte')}},
	{{validate_Future_Date('Stf_Term_Dte')}},
	{{validate_NoFutureDate('Stf_Join_Dte')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_NoFutureDate('Relevant_Indv_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__Future_Date_valid_Relevant_Indv_End_Dte',__Future_Date_valid_Stf_Term_Dte',__NoFutureDate_valid_Stf_Join_Dte',__CountryCode_valid_Issue_Country_Code',__NoFutureDate_valid_Relevant_Indv_Start_Dte']) }}
FROM CTE_3)