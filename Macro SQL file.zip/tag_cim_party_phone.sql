CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Phone('Day_Time_Phone_Nbr')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_Phone('Home_Phone_Nbr')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_Phone('Mobile_Phone_Nbr')}},
	{{validate_Phone('Office_Phone_Nbr')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Phone_valid_Day_Time_Phone_Nbr',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__Phone_valid_Home_Phone_Nbr',__CountryCode_valid_Issue_Country_Code',__Phone_valid_Mobile_Phone_Nbr',__Phone_valid_Office_Phone_Nbr']) }}
FROM CTE_3)