CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Progress_Cmple_Dte')}},
	{{validate_NoFutureDate('Progress_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Progress_Cmple_Dte',__NoFutureDate_valid_Progress_Start_Dte']) }}
FROM CTE_3)