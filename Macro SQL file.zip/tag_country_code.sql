CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Country_Code')}},
	{{validate_CountryCode('Country_Name')}},
	{{validate_01YN('Country_Risk_Ind')}},
	{{validate_01YN('CRS_Report_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Country_Code',__CountryCode_valid_Country_Name',__01YN_valid_Country_Risk_Ind',__01YN_valid_CRS_Report_Ind']) }}
FROM CTE_3)