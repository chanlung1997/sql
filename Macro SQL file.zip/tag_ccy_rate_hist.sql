CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Ccy_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Ccy_Dte']) }}
FROM CTE_3)