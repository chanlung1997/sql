CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Limit_End_Dte')}},
	{{validate_NoFutureDate('Limit_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Limit_End_Dte',__NoFutureDate_valid_Limit_Start_Dte']) }}
FROM CTE_3)