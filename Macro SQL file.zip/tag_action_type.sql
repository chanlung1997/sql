CTE_3 AS (
	SELECT
	*,
	{{validate_Action_Type_Desc('Action_Type_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__Action_Type_Desc_valid_Action_Type_Desc']) }}
FROM CTE_3)