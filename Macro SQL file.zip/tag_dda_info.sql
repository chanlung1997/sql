CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_11('Dep_Acct_Nbr')}},
	{{validate_Max_len_16('Wdl_Acct_Nbr')}},
	{{validate_Max_len_16('Internal_Nbr')}},
	{{validate_Mandate_Type('Mandate_Type')}},
	{{validate_Pmt_Limit_Type('Pmt_Limit_Type')}},
	{{validate_Trx_Type('Trx_Type')}},
	{{validate_NoFutureDate('Create_Dte')}},
	{{validate_Future_Date('Eff_Dte')}},
	{{validate_Future_Date('Expiry_Dte')}},
	{{validate_NoFutureDate('Last_Checking_Dte')}},
	{{validate_NoFutureDate('Last_Pmt_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_11_valid_Dep_Acct_Nbr',__Max_len_16_valid_Wdl_Acct_Nbr',__Max_len_16_valid_Internal_Nbr',__Mandate_Type_valid_Mandate_Type',__Pmt_Limit_Type_valid_Pmt_Limit_Type',__Trx_Type_valid_Trx_Type',__NoFutureDate_valid_Create_Dte',__Future_Date_valid_Eff_Dte',__Future_Date_valid_Expiry_Dte',__NoFutureDate_valid_Last_Checking_Dte',__NoFutureDate_valid_Last_Pmt_Dte']) }}
FROM CTE_3)