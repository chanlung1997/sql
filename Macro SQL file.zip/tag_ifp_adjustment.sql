CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Date')}},
	{{validate_01YN('Compare_Rate_Flag')}},
	{{validate_Future_Date('Int_Val_Date')}},
	{{validate_Future_Date('Maturity_Date')}},
	{{validate_NoFutureDate('Eff_Backdate')}},
	{{validate_01YNYesNo('Flg_Backdate')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Date',__01YN_valid_Compare_Rate_Flag',__Future_Date_valid_Int_Val_Date',__Future_Date_valid_Maturity_Date',__NoFutureDate_valid_Eff_Backdate',__01YNYesNo_valid_Flg_Backdate']) }}
FROM CTE_3)