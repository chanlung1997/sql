CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_10('Acct_Nbr')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_10_valid_Acct_Nbr',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code']) }}
FROM CTE_3)