CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('IP_Country_Code')}},
	{{validate_NoFutureDate('Start_Event_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_IP_Country_Code',__NoFutureDate_valid_Start_Event_Dte']) }}
FROM CTE_3)