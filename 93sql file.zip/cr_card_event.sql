WITH  CTE_1  AS(   
SELECT 
	* 
FROM  gcp-prj-dat-bigquery-dev-00.bqd_015_raw.tag_cr_card_event_raw 
),   
 
CTE_2  AS  ( 
SELECT
	CAST(Event_Id  AS  STRING)  AS  Event_Id,
	CAST(Mcc_Code  AS  STRING)  AS  Mcc_Code,
	CAST(Mrch_Nbr  AS  STRING)  AS  Mrch_Nbr,
	CAST(Mrch_Org_Nbr  AS  STRING)  AS  Mrch_Org_Nbr
FROM  CTE_1 
),   
 
CTE_3  AS  ( 
	SELECT   
	*,
Event_Id,
Mcc_Code,
Mrch_Nbr,
Mrch_Org_Nbr,
	''  AS  __full_load_valid   
FROM  CTE_2 
)
 
SELECT  *  FROM  CTE_3
