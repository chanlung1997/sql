CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Doc_Expiry_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_Future_Date('Incorporation_Dte')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('Dte_Of_Birth')}},
	{{validate_GenderCode('Gender_Code')}},
	{{validate_IndustryCode('Industry_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_MaritalStatus('Marital_Status')}},
	{{validate_NoFutureDate('Party_Start_Dte')}},
	{{validate_TitleCode('Title_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Doc_Expiry_Dte',__HKID_valid_Doc_Nbr',__Future_Date_valid_Incorporation_Dte',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_Dte_Of_Birth',__GenderCode_valid_Gender_Code',__IndustryCode_valid_Industry_Code',__CountryCode_valid_Issue_Country_Code',__MaritalStatus_valid_Marital_Status',__NoFutureDate_valid_Party_Start_Dte',__TitleCode_valid_Title_Code']) }}
FROM CTE_3)