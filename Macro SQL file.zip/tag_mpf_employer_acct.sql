CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_13('Mpfa_Participation_Nbr')}},
	{{validate_Future_Date('First_Aprov_Dte')}},
	{{validate_NoFutureDate('Mand_Contrib_Fst_Cover_End_Dte')}},
	{{validate_IndustryCode('Industry_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_13_valid_Mpfa_Participation_Nbr',__Future_Date_valid_First_Aprov_Dte',__NoFutureDate_valid_Mand_Contrib_Fst_Cover_End_Dte',__IndustryCode_valid_Industry_Code']) }}
FROM CTE_3)