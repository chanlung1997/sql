CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date_NotNumerical('Letter_Dte')}},
	{{validate_Future_Date_NotNumerical('Reply_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_NotNumerical_valid_Letter_Dte',__Future_Date_NotNumerical_valid_Reply_Dte']) }}
FROM CTE_3)