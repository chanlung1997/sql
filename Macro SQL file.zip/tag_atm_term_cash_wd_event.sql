CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Cash_Wd_Last_Event_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Cash_Wd_Last_Event_Dte']) }}
FROM CTE_3)