CREATE  OR  REPLACE  TABLE  `bqd_015_raw.tag_marital_status_raw`  (
Marital_Status  STRING(1),
Marital_Status_Desc  STRING(30),
__batch_date  TIMESTAMP,   
__load_date  TIMESTAMP,   
__file_name  STRING,   
__load_type  STRING,   
__sys_code  STRING,   
__row_number  STRING 
);
