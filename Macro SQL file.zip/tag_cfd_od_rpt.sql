CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_10('HKMC_Ref_Nbr')}},
	{{validate_Max_len_10('Link_Entity_Nbr')}},
	{{validate_Max_len_15('Acct_Nbr')}},
	{{validate_NoFutureDate('Credit_Create_Dte')}},
	{{validate_Future_Date('Credit_Expiry_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_Future_Date('Reopen_Dte')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_NoFutureDate('Last_Dep_Dte')}},
	{{validate_NoFutureDate('Last_Review_Dte')}},
	{{validate_NoFutureDate('Last_Suspend_Dte')}},
	{{validate_NoFutureDate('Recal_Dte')}},
	{{validate_NoFutureDate('Last_Update_Dte')}},
	{{validate_Phone('Mobile_Phone_Nbr')}},
	{{validate_01YN('Broker_Ind')}},
	{{validate_01YN('Chn_Od_Ind')}},
	{{validate_01YN('Loan_Resend_Ind')}},
	{{validate_01YN('Min_Pay_Waive_Ind')}},
	{{validate_Phone('Office_Phone_Nbr')}},
	{{validate_NoFutureDate('Review_Dte')}},
	{{validate_Phone('Primary_Phone_Nbr')}},
	{{validate_Phone('Residential_Phone_Nbr')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_10_valid_HKMC_Ref_Nbr',__Max_len_10_valid_Link_Entity_Nbr',__Max_len_15_valid_Acct_Nbr',__NoFutureDate_valid_Credit_Create_Dte',__Future_Date_valid_Credit_Expiry_Dte',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__Future_Date_valid_Reopen_Dte',__CountryCode_valid_Issue_Country_Code',__NoFutureDate_valid_Last_Dep_Dte',__NoFutureDate_valid_Last_Review_Dte',__NoFutureDate_valid_Last_Suspend_Dte',__NoFutureDate_valid_Recal_Dte',__NoFutureDate_valid_Last_Update_Dte',__Phone_valid_Mobile_Phone_Nbr',__01YN_valid_Broker_Ind',__01YN_valid_Chn_Od_Ind',__01YN_valid_Loan_Resend_Ind',__01YN_valid_Min_Pay_Waive_Ind',__Phone_valid_Office_Phone_Nbr',__NoFutureDate_valid_Review_Dte',__Phone_valid_Primary_Phone_Nbr',__Phone_valid_Residential_Phone_Nbr']) }}
FROM CTE_3)