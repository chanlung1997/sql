CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Licence_Expiry_Dte')}},
	{{validate_Future_Date('Release_Dte')}},
	{{validate_NoFutureDate('Company_Chrg_Dte')}},
	{{validate_NoFutureDate('Govt_Chrg_Dte')}},
	{{validate_01YN('Cross_Border_Ind')}},
	{{validate_01YN('First_Hand_Ind')}},
	{{validate_01YN('Repossess_Vehicle_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Licence_Expiry_Dte',__Future_Date_valid_Release_Dte',__NoFutureDate_valid_Company_Chrg_Dte',__NoFutureDate_valid_Govt_Chrg_Dte',__01YN_valid_Cross_Border_Ind',__01YN_valid_First_Hand_Ind',__01YN_valid_Repossess_Vehicle_Ind']) }}
FROM CTE_3)