CTE_3 AS (
	SELECT
	*,
	{{validate_Event_Type_3items('Event_Type')}},
	{{validate_Future_Date('Val_Dte')}},
	{{validate_NoFutureDate('Delivery_Dte')}},
	{{validate_NoFutureDate('Expiry_Dte')}},
	{{validate_CountryCode('Event_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Event_Type_3items_valid_Event_Type',__Future_Date_valid_Val_Dte',__NoFutureDate_valid_Delivery_Dte',__NoFutureDate_valid_Expiry_Dte',__CountryCode_valid_Event_Country_Code']) }}
FROM CTE_3)