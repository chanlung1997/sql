CTE_3 AS (
	SELECT
	*,
	{{validate_Acpt_len_9_12_14_15('Acct_Nbr')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('High_Value_Dte')}},
	{{validate_CountryCode('Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Acpt_len_9_12_14_15_valid_Acct_Nbr',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_High_Value_Dte',__CountryCode_valid_Issue_Country_Code']) }}
FROM CTE_3)