CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('COUNTRY_CODE')}},
	{{validate_CountryCode('COUNTRY_NAME')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_COUNTRY_CODE',__CountryCode_valid_COUNTRY_NAME']) }}
FROM CTE_3)