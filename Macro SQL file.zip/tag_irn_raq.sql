CTE_3 AS (
	SELECT
	*,
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_Quest_Type('Quest_Type')}},
	{{validate_01YN('Disagree_Flag')}},
	{{validate_NoFutureDate('Sign_Dte')}},
	{{validate_NoFutureDate('Dte_Of_Birth_Incorporation')}},
	{{validate_CountryCode('Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__Quest_Type_valid_Quest_Type',__01YN_valid_Disagree_Flag',__NoFutureDate_valid_Sign_Dte',__NoFutureDate_valid_Dte_Of_Birth_Incorporation',__CountryCode_valid_Issue_Country_Code']) }}
FROM CTE_3)