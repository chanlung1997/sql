CTE_3 AS (
	SELECT
	*,
	{{validate_HKID('Doc_Nbr')}},
	{{validate_NoFutureDate('Appl_Dte')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('Status_Dte')}},
	{{validate_CountryCode('Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__HKID_valid_Doc_Nbr',__NoFutureDate_valid_Appl_Dte',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_Status_Dte',__CountryCode_valid_Issue_Country_Code']) }}
FROM CTE_3)