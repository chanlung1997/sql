CTE_3 AS (
	SELECT
	*,
	{{validate_Acpt_len_44to46_50('Ref_Nbr')}},
	{{validate_Acpt_len_5to11_13to15('Doc_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Acpt_len_9_14to16('Acct_Nbr')}},
	{{validate_NoFutureDate('Input_Dte')}},
	{{validate_CountryCode('Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Acpt_len_44to46_50_valid_Ref_Nbr',__Acpt_len_5to11_13to15_valid_Doc_Nbr',__NoFutureDate_valid_Batch_Dte',__Acpt_len_9_14to16_valid_Acct_Nbr',__NoFutureDate_valid_Input_Dte',__CountryCode_valid_Issue_Country_Code']) }}
FROM CTE_3)