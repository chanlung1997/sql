CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_14('Acct_Nbr')}},
	{{validate_Max_len_14('Seq_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_Future_Date('Stf_Term_Dte')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_14_valid_Acct_Nbr',__Max_len_14_valid_Seq_Nbr',__NoFutureDate_valid_Batch_Dte',__HKID_valid_Doc_Nbr',__Future_Date_valid_Stf_Term_Dte',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code']) }}
FROM CTE_3)