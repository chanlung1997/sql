CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Eff_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Eff_Dte']) }}
FROM CTE_3)