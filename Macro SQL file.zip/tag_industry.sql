CTE_3 AS (
	SELECT
	*,
	{{validate_IndustryCode('Industry_Code')}},
	{{validate_Industry_Desc('Industry_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__IndustryCode_valid_Industry_Code',__Industry_Desc_valid_Industry_Desc']) }}
FROM CTE_3)