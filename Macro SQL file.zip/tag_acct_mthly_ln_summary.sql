CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('No_Min_Pay_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_No_Min_Pay_Ind']) }}
FROM CTE_3)