CTE_3 AS (
	SELECT
	*,
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_NoFutureDate('Qualf_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code',__NoFutureDate_valid_Qualf_Start_Dte']) }}
FROM CTE_3)