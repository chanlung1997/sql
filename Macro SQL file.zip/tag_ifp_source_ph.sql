CTE_3 AS (
	SELECT
	*,
	{{validate_NoAlphas('Backdate_Amt_Hkd')}},
	{{validate_NoFutureDate('Backdate_Tx_Date')}},
	{{validate_01YNYesNo('Backdate_Tx_Flag')}},
	{{validate_01YN('Campaign_Basis_Flag')}},
	{{validate_01YN('Capped_Rate_Flag')}},
	{{validate_01YN('Compare_Rate_Flag')}},
	{{validate_01YN('Cust_Rate_Basis_Flag')}},
	{{validate_NoFutureDate('IFP_Processing_Date')}},
	{{validate_01YN('Facility_Maturity_Flag')}},
	{{validate_01YN('Fixed_Rate_Flag')}},
	{{validate_01YN('IRS_Hedged_Flag')}},
	{{validate_01YN('Revolving_Flag')}},
	{{validate_01YNYesNo('Scheduled_PPL_Repay_Flag')}}
FROM CTE_2
),
{{ full_valid_flag([__NoAlphas_valid_Backdate_Amt_Hkd',__NoFutureDate_valid_Backdate_Tx_Date',__01YNYesNo_valid_Backdate_Tx_Flag',__01YN_valid_Campaign_Basis_Flag',__01YN_valid_Capped_Rate_Flag',__01YN_valid_Compare_Rate_Flag',__01YN_valid_Cust_Rate_Basis_Flag',__NoFutureDate_valid_IFP_Processing_Date',__01YN_valid_Facility_Maturity_Flag',__01YN_valid_Fixed_Rate_Flag',__01YN_valid_IRS_Hedged_Flag',__01YN_valid_Revolving_Flag',__01YNYesNo_valid_Scheduled_PPL_Repay_Flag']) }}
FROM CTE_3)