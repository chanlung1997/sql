CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Create_Dte')}},
	{{validate_Future_Date('Gift_Paid_Dte')}},
	{{validate_NoFutureDate('Val_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Create_Dte',__Future_Date_valid_Gift_Paid_Dte',__NoFutureDate_valid_Val_Dte']) }}
FROM CTE_3)