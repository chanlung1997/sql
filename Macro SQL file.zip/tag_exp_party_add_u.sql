CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Acpt_9999_space('Ctry_Val_Update_Ctr_Id')}},
	{{validate_CountryCode('Country_Code')}},
	{{validate_NoFutureDate('Ctry_Val_Update_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_NoFutureDate('Last_Update_Dte')}},
	{{validate_Ctry_Val_Update_Offr_Id('Ctry_Val_Update_Offr_Id')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Acpt_9999_space_valid_Ctry_Val_Update_Ctr_Id',__CountryCode_valid_Country_Code',__NoFutureDate_valid_Ctry_Val_Update_Dte',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code',__NoFutureDate_valid_Last_Update_Dte',__Ctry_Val_Update_Offr_Id_valid_Ctry_Val_Update_Offr_Id']) }}
FROM CTE_3)