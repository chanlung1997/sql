CTE_3 AS (
	SELECT
	*,
	{{validate_Acpt_len_9_14to16('Acct_Nbr')}}
FROM CTE_2
),
{{ full_valid_flag([__Acpt_len_9_14to16_valid_Acct_Nbr']) }}
FROM CTE_3)