CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Val_Dte')}},
	{{validate_01YN('Cash_Trx_Ind')}},
	{{validate_01YN('CNH_Rate_Ind')}},
	{{validate_01YN('CNY_Trx_Amt_Override_Ind')}},
	{{validate_01YN('CNY_Trx_Cnt_Override_Ind')}},
	{{validate_01YN('Correction_Ind')}},
	{{validate_01YN('Event_Posted_Ind')}},
	{{validate_01YN('Third_Party_Trx_Ind')}},
	{{validate_01YN('Trade_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Val_Dte',__01YN_valid_Cash_Trx_Ind',__01YN_valid_CNH_Rate_Ind',__01YN_valid_CNY_Trx_Amt_Override_Ind',__01YN_valid_CNY_Trx_Cnt_Override_Ind',__01YN_valid_Correction_Ind',__01YN_valid_Event_Posted_Ind',__01YN_valid_Third_Party_Trx_Ind',__01YN_valid_Trade_Ind']) }}
FROM CTE_3)