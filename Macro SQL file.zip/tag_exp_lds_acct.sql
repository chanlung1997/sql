CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Future_Date('Maturity_Dte')}},
	{{validate_Future_Date('Mstr_Agreement_Dte')}},
	{{validate_Future_Date('Settle_Dte')}},
	{{validate_NoFutureDate('Trade_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Future_Date_valid_Maturity_Dte',__Future_Date_valid_Mstr_Agreement_Dte',__Future_Date_valid_Settle_Dte',__NoFutureDate_valid_Trade_Dte']) }}
FROM CTE_3)