CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Create_Dte')}},
	{{validate_NoFutureDate('Cancel_Dte')}},
	{{validate_NoFutureDate('Confirm_Dte')}},
	{{validate_NoFutureDate('Rej_Dte')}},
	{{validate_NoFutureDate('Review_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Create_Dte',__NoFutureDate_valid_Cancel_Dte',__NoFutureDate_valid_Confirm_Dte',__NoFutureDate_valid_Rej_Dte',__NoFutureDate_valid_Review_Dte']) }}
FROM CTE_3)