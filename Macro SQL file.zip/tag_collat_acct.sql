CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Expiry_Dte')}},
	{{validate_01YN('Cr_Facility_Ind')}},
	{{validate_01YN('Custody_Ind')}},
	{{validate_01YN('Shell_Company_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Expiry_Dte',__01YN_valid_Cr_Facility_Ind',__01YN_valid_Custody_Ind',__01YN_valid_Shell_Company_Ind']) }}
FROM CTE_3)