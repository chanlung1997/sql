CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Actvn_Dte')}},
	{{validate_Max_len_14('Acct_Nbr')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_NoFutureDate('Last_Modify_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Actvn_Dte',__Max_len_14_valid_Acct_Nbr',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code',__NoFutureDate_valid_Last_Modify_Dte']) }}
FROM CTE_3)