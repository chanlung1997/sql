CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Ben_Country_Code')}},
	{{validate_CountryCode('Ben_Instit_Country_Code')}},
	{{validate_CountryCode('Ext_Cust_Country_Code')}},
	{{validate_01YN('Backdate_Ind')}},
	{{validate_CountryCode('Instit_Country_Code')}},
	{{validate_CountryCode('Inter_Bank_Country_Code')}},
	{{validate_CountryCode('Ultimate_Instit_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Ben_Country_Code',__CountryCode_valid_Ben_Instit_Country_Code',__CountryCode_valid_Ext_Cust_Country_Code',__01YN_valid_Backdate_Ind',__CountryCode_valid_Instit_Country_Code',__CountryCode_valid_Inter_Bank_Country_Code',__CountryCode_valid_Ultimate_Instit_Country_Code']) }}
FROM CTE_3)