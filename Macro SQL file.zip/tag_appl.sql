CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Appl_Dte')}},
	{{validate_NoFutureDate('Aprov_Dte')}},
	{{validate_NoFutureDate('Status_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Appl_Dte',__NoFutureDate_valid_Aprov_Dte',__NoFutureDate_valid_Status_Dte']) }}
FROM CTE_3)