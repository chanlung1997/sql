CTE_3 AS (
	SELECT
	*,
	{{validate_Acct_Type_Desc('Acct_Type_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__Acct_Type_Desc_valid_Acct_Type_Desc']) }}
FROM CTE_3)