CTE_3 AS (
	SELECT
	*,
	{{validate_OccupCode('Occup_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__OccupCode_valid_Occup_Code']) }}
FROM CTE_3)