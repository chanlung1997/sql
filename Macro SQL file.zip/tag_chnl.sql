CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Chnl_Start_Dte')}},
	{{validate_Future_Date('Chnl_End_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Chnl_Start_Dte',__Future_Date_valid_Chnl_End_Dte']) }}
FROM CTE_3)