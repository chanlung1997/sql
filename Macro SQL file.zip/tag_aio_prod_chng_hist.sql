CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Eff_Dte')}},
	{{validate_NoFutureDate('Request_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Eff_Dte',__NoFutureDate_valid_Request_Dte']) }}
FROM CTE_3)