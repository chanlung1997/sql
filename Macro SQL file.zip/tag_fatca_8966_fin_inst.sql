CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Add_Country_Code')}},
	{{validate_Max_len_17('Ref_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_NoFutureDate('Input_Dte')}},
	{{validate_CountryCode('Sponsor_Add_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Add_Country_Code',__Max_len_17_valid_Ref_Nbr',__NoFutureDate_valid_Batch_Dte',__NoFutureDate_valid_Input_Dte',__CountryCode_valid_Sponsor_Add_Country_Code']) }}
FROM CTE_3)