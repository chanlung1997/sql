CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Quest_Type('Quest_Type')}},
	{{validate_01YN('Disagree_Flag')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('Dte_Of_Birth_Incorporation')}},
	{{validate_NoFutureDate('Sign_Dte')}},
	{{validate_CountryCode('Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Quest_Type_valid_Quest_Type',__01YN_valid_Disagree_Flag',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_Dte_Of_Birth_Incorporation',__NoFutureDate_valid_Sign_Dte',__CountryCode_valid_Issue_Country_Code']) }}
FROM CTE_3)