CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Create_Dte')}},
	{{validate_Future_Date('Int_Rate_End_Dte')}},
	{{validate_NoFutureDate('Int_Rate_Start_Dte')}},
	{{validate_01YN('Fix_Rate_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Create_Dte',__Future_Date_valid_Int_Rate_End_Dte',__NoFutureDate_valid_Int_Rate_Start_Dte',__01YN_valid_Fix_Rate_Ind']) }}
FROM CTE_3)