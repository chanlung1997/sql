CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Plan_Eff_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Plan_Eff_Dte']) }}
FROM CTE_3)