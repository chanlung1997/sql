CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Chnl_Type_Start_Dte')}},
	{{validate_Chnl_Type_Name('Chnl_Type_Name')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Chnl_Type_Start_Dte',__Chnl_Type_Name_valid_Chnl_Type_Name']) }}
FROM CTE_3)