CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_27('Ref_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Acpt_len_8('Related_Doc_Nbr')}},
	{{validate_CountryCode('Related_Add_Country_Code')}},
	{{validate_NoFutureDate('Related_Birth_Dte')}},
	{{validate_CountryCode('Related_Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_27_valid_Ref_Nbr',__NoFutureDate_valid_Batch_Dte',__Acpt_len_8_valid_Related_Doc_Nbr',__CountryCode_valid_Related_Add_Country_Code',__NoFutureDate_valid_Related_Birth_Dte',__CountryCode_valid_Related_Issue_Country_Code']) }}
FROM CTE_3)