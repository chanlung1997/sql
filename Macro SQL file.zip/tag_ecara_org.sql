CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_12('Acct_nbr')}},
	{{validate_NoFutureDate('Approval_Dte')}},
	{{validate_Max_len_15('CARA_Ref_Nbr')}},
	{{validate_NoFutureDate('Creation_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_IndustryCode('Industry_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_OccupCode('Occup_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_12_valid_Acct_nbr',__NoFutureDate_valid_Approval_Dte',__Max_len_15_valid_CARA_Ref_Nbr',__NoFutureDate_valid_Creation_Dte',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__IndustryCode_valid_Industry_Code',__CountryCode_valid_Issue_Country_Code',__OccupCode_valid_Occup_Code']) }}
FROM CTE_3)