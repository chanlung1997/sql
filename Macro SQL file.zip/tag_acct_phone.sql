CTE_3 AS (
	SELECT
	*,
	{{validate_Phone('Phone_Nbr')}},
	{{validate_PhoneTypeCode('Phone_Type_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Phone_valid_Phone_Nbr',__PhoneTypeCode_valid_Phone_Type_Code']) }}
FROM CTE_3)