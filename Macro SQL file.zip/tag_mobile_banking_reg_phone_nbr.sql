CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_15('Acct_Nbr')}},
	{{validate_Phone('Phone_Nbr')}},
	{{validate_NoFutureDate('Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_15_valid_Acct_Nbr',__Phone_valid_Phone_Nbr',__NoFutureDate_valid_Start_Dte']) }}
FROM CTE_3)