CTE_3 AS (
	SELECT
	*,
	{{validate_HKID('Doc_Nbr')}},
	{{validate_Future_Date('Mrch_Close_Dte')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('Mrch_Open_Dte')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_NoFutureDate('Last_Actv_Dte')}},
	{{validate_NoFutureDate('Last_Maint_Dte')}},
	{{validate_Phone('Phone_Nbr')}}
FROM CTE_2
),
{{ full_valid_flag([__HKID_valid_Doc_Nbr',__Future_Date_valid_Mrch_Close_Dte',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_Mrch_Open_Dte',__CountryCode_valid_Issue_Country_Code',__NoFutureDate_valid_Last_Actv_Dte',__NoFutureDate_valid_Last_Maint_Dte',__Phone_valid_Phone_Nbr']) }}
FROM CTE_3)