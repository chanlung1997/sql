CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Acpt_len_39_42_44to49('Ref_Nbr')}},
	{{validate_Acpt_len_9_14to16('Acct_Nbr')}},
	{{validate_NoFutureDate('Input_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Acpt_len_39_42_44to49_valid_Ref_Nbr',__Acpt_len_9_14to16_valid_Acct_Nbr',__NoFutureDate_valid_Input_Dte']) }}
FROM CTE_3)