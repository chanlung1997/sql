CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Create_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_Future_Date('Expiry_Dte')}},
	{{validate_Future_Date('Maturity_Dte')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_NoFutureDate('Last_Update_Dte')}},
	{{validate_NoFutureDate('Trade_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Create_Dte',__HKID_valid_Doc_Nbr',__Future_Date_valid_Expiry_Dte',__Future_Date_valid_Maturity_Dte',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code',__NoFutureDate_valid_Last_Update_Dte',__NoFutureDate_valid_Trade_Dte']) }}
FROM CTE_3)