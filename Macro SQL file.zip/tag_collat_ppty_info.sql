CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Cmple_Dte')}},
	{{validate_Future_Date('Est_Val_Dte')}},
	{{validate_Future_Date('Net_Realz_Val_Dte')}},
	{{validate_Future_Date('Portfolio_Val_Dte')}},
	{{validate_NoFutureDate('HKMC_Valuation_Dte')}},
	{{validate_NoFutureDate('Chrg_Code_Chng_Dte')}},
	{{validate_NoFutureDate('Foresale_Val_Dte')}},
	{{validate_NoFutureDate('Lease_Term_Comm_Dte')}},
	{{validate_NoFutureDate('Occup_Permit_Dte')}},
	{{validate_NoFutureDate('Purchase_Dte')}},
	{{validate_NoFutureDate('Reconstruct_Val_Dte')}},
	{{validate_01YN('Already_Own_Ind')}},
	{{validate_01YN('New_Property_Ind')}},
	{{validate_01YN('Rental_Assign_Ind')}},
	{{validate_CountryCode('Ppty_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Cmple_Dte',__Future_Date_valid_Est_Val_Dte',__Future_Date_valid_Net_Realz_Val_Dte',__Future_Date_valid_Portfolio_Val_Dte',__NoFutureDate_valid_HKMC_Valuation_Dte',__NoFutureDate_valid_Chrg_Code_Chng_Dte',__NoFutureDate_valid_Foresale_Val_Dte',__NoFutureDate_valid_Lease_Term_Comm_Dte',__NoFutureDate_valid_Occup_Permit_Dte',__NoFutureDate_valid_Purchase_Dte',__NoFutureDate_valid_Reconstruct_Val_Dte',__01YN_valid_Already_Own_Ind',__01YN_valid_New_Property_Ind',__01YN_valid_Rental_Assign_Ind',__CountryCode_valid_Ppty_Country_Code']) }}
FROM CTE_3)