CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Advance_Dte')}},
	{{validate_CountryCode('Ln_Use_Country')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Advance_Dte',__CountryCode_valid_Ln_Use_Country']) }}
FROM CTE_3)