CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Actl_Drawdn_Dte')}},
	{{validate_Future_Date('Maturity_Dte')}},
	{{validate_01YN('Fix_Insl_Nbr_Or_Amt_Ind')}},
	{{validate_01YN('Ln_Aprov_Marginal_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Actl_Drawdn_Dte',__Future_Date_valid_Maturity_Dte',__01YN_valid_Fix_Insl_Nbr_Or_Amt_Ind',__01YN_valid_Ln_Aprov_Marginal_Ind']) }}
FROM CTE_3)