CTE_3 AS (
	SELECT
	*,
	{{validate_Acpt_range_0132to9999('Ctry_Val_Update_Ctr_Id')}},
	{{validate_CountryCode('Country_Code')}},
	{{validate_NoFutureDate('Ctry_Val_Update_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_Acpt_len_6_7_space_null('Ctry_Val_Update_Offr_Id')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_NoFutureDate('Last_Update_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Acpt_range_0132to9999_valid_Ctry_Val_Update_Ctr_Id',__CountryCode_valid_Country_Code',__NoFutureDate_valid_Ctry_Val_Update_Dte',__HKID_valid_Doc_Nbr',__Acpt_len_6_7_space_null_valid_Ctry_Val_Update_Offr_Id',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code',__NoFutureDate_valid_Last_Update_Dte']) }}
FROM CTE_3)