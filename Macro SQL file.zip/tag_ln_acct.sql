CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Maturity_Dte')}},
	{{validate_Future_Date('Pmt_Due_Dte')}},
	{{validate_Future_Date('Ppsl_Dte')}},
	{{validate_NoFutureDate('Rate_Chng_Eff_Dte')}},
	{{validate_NoFutureDate('Int_Start_Dte')}},
	{{validate_NoFutureDate('Last_Rate_Chng_Dte')}},
	{{validate_NoFutureDate('Last_Settle_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Maturity_Dte',__Future_Date_valid_Pmt_Due_Dte',__Future_Date_valid_Ppsl_Dte',__NoFutureDate_valid_Rate_Chng_Eff_Dte',__NoFutureDate_valid_Int_Start_Dte',__NoFutureDate_valid_Last_Rate_Chng_Dte',__NoFutureDate_valid_Last_Settle_Dte']) }}
FROM CTE_3)