CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Coll_Act_Dte')}},
	{{validate_Future_Date('Re_Act_Dte')}},
	{{validate_NoFutureDate('Coll_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Coll_Act_Dte',__Future_Date_valid_Re_Act_Dte',__NoFutureDate_valid_Coll_Dte']) }}
FROM CTE_3)