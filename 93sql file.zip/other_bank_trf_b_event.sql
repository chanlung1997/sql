WITH  CTE_1  AS(   
SELECT 
	* 
FROM  gcp-prj-dat-bigquery-dev-00.bqd_015_raw.tag_other_bank_trf_b_event_raw 
),   
 
CTE_2  AS  ( 
SELECT
	CAST(Event_Id  AS  STRING)  AS  Event_Id,
	CAST(Ben_Instit_Name  AS  STRING)  AS  Ben_Instit_Name,
	CAST(Ben_Name  AS  STRING)  AS  Ben_Name,
	CAST(Ccy_Code  AS  STRING)  AS  Ccy_Code,
	CAST(Event_Rem  AS  STRING)  AS  Event_Rem,
	CAST(Ext_Cust_Info  AS  STRING)  AS  Ext_Cust_Info,
	CAST(Instit_Info_Rem  AS  STRING)  AS  Instit_Info_Rem,
	CAST(Instr_Amt  AS  NUMERIC)  AS  Instr_Amt,
	CAST(Instr_Amt_Hke  AS  NUMERIC)  AS  Instr_Amt_Hke,
	CAST(Inter_Bank_Info  AS  STRING)  AS  Inter_Bank_Info,
	CAST(Sender_Receiver_Info  AS  STRING)  AS  Sender_Receiver_Info
FROM  CTE_1 
),   
 
CTE_3  AS  ( 
	SELECT   
	*,
Event_Id,
Ben_Instit_Name,
Ben_Name,
Ccy_Code,
Event_Rem,
Ext_Cust_Info,
Instit_Info_Rem,
Instr_Amt,
Instr_Amt_Hke,
Inter_Bank_Info,
Sender_Receiver_Info,
	''  AS  __full_load_valid   
FROM  CTE_2 
)
 
SELECT  *  FROM  CTE_3
