CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Last_Settle_Dte')}},
	{{validate_NoFutureDate('Period_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Last_Settle_Dte',__NoFutureDate_valid_Period_Start_Dte']) }}
FROM CTE_3)