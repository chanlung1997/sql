CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_10('Item_Serial_Nbr')}},
	{{validate_NoFutureDate('Insl_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_10_valid_Item_Serial_Nbr',__NoFutureDate_valid_Insl_Start_Dte']) }}
FROM CTE_3)