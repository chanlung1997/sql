CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('First_Feature_Enable_Dte')}},
	{{validate_01YN('Feature_Enable_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_First_Feature_Enable_Dte',__01YN_valid_Feature_Enable_Ind']) }}
FROM CTE_3)