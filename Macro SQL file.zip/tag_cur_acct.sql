CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Od_Limit_Close_Dte')}},
	{{validate_NoFutureDate('Int_Suspend_Dte')}},
	{{validate_NoFutureDate('Od_Limit_Open_Dte')}},
	{{validate_NoFutureDate('Od_Limit_Suspend_Dte')}},
	{{validate_NoFutureDate('Review_Dte')}},
	{{validate_NoFutureDate('Last_Review_Dte')}},
	{{validate_NoFutureDate('Last_xxx_Od_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Od_Limit_Close_Dte',__NoFutureDate_valid_Int_Suspend_Dte',__NoFutureDate_valid_Od_Limit_Open_Dte',__NoFutureDate_valid_Od_Limit_Suspend_Dte',__NoFutureDate_valid_Review_Dte',__NoFutureDate_valid_Last_Review_Dte',__NoFutureDate_valid_Last_xxx_Od_Start_Dte']) }}
FROM CTE_3)