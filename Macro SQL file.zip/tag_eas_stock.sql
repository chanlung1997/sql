CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Expiry_dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Expiry_dte']) }}
FROM CTE_3)