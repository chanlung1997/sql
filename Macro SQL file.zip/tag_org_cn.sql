CTE_3 AS (
	SELECT
	*,
	{{validate_HKID('Doc_Nbr')}},
	{{validate_Future_Date('Incorporation_Dte')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__HKID_valid_Doc_Nbr',__Future_Date_valid_Incorporation_Dte',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code']) }}
FROM CTE_3)