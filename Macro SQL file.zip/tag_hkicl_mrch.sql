CTE_3 AS (
	SELECT
	*,
	{{validate_Corporate_Type('Corporate_Type')}}
FROM CTE_2
),
{{ full_valid_flag([__Corporate_Type_valid_Corporate_Type']) }}
FROM CTE_3)