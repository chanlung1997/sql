CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_3('Seq_Nbr')}},
	{{validate_Future_Date('Purchase_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_3_valid_Seq_Nbr',__Future_Date_valid_Purchase_Dte']) }}
FROM CTE_3)