CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Ben_Add_Country_Code')}},
	{{validate_NoFutureDate('Ben_Dte_Of_Birth')}},
	{{validate_CountryCode('Ben_Issue_Country_Code')}},
	{{validate_CountryCode('Corp_Cust_Issue_Country_Code')}},
	{{validate_CountryCode('Corp_Cust_Off_Add_Country_Code')}},
	{{validate_CountryCode('Corp_Cust_Reg_Add_Country_Code')}},
	{{validate_NoFutureDate('Corp_Cust_Incorporation_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Ben_Add_Country_Code',__NoFutureDate_valid_Ben_Dte_Of_Birth',__CountryCode_valid_Ben_Issue_Country_Code',__CountryCode_valid_Corp_Cust_Issue_Country_Code',__CountryCode_valid_Corp_Cust_Off_Add_Country_Code',__CountryCode_valid_Corp_Cust_Reg_Add_Country_Code',__NoFutureDate_valid_Corp_Cust_Incorporation_Dte']) }}
FROM CTE_3)