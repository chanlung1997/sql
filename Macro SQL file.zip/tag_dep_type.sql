CTE_3 AS (
	SELECT
	*,
	{{validate_Dep_Type_Desc('Dep_Type_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__Dep_Type_Desc_valid_Dep_Type_Desc']) }}
FROM CTE_3)