CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Mcs_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Mcs_Ind']) }}
FROM CTE_3)