CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Due_Dte')}},
	{{validate_NoFutureDate('Od_Settle_Dte')}},
	{{validate_NoFutureDate('Last_Settle_Dte')}},
	{{validate_NoFutureDate('Period_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Due_Dte',__NoFutureDate_valid_Od_Settle_Dte',__NoFutureDate_valid_Last_Settle_Dte',__NoFutureDate_valid_Period_Start_Dte']) }}
FROM CTE_3)