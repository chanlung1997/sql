CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Actvn_Dte')}},
	{{validate_NoFutureDate('Aprov_Dte')}},
	{{validate_NoFutureDate('Cancl_Dte')}},
	{{validate_NoFutureDate('Appl_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Actvn_Dte',__NoFutureDate_valid_Aprov_Dte',__NoFutureDate_valid_Cancl_Dte',__NoFutureDate_valid_Appl_Dte']) }}
FROM CTE_3)