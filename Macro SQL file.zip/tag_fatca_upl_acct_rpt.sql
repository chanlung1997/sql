CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_16('Acct_Nbr')}},
	{{validate_Acpt_len_39_44to46('Ref_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_NoFutureDate('Input_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_16_valid_Acct_Nbr',__Acpt_len_39_44to46_valid_Ref_Nbr',__NoFutureDate_valid_Batch_Dte',__NoFutureDate_valid_Input_Dte']) }}
FROM CTE_3)