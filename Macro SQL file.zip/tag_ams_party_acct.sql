CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Acct_Party_End_Dte')}},
	{{validate_NoFutureDate('Acct_Party_Start_Dte')}},
	{{validate_Max_len_16('Orig_Acct_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Max_len_19('Acct_Nbr')}},
	{{validate_Acpt_len_8('Party_Intl_Nbr')}},
	{{validate_Acpt_value_A_U_D_space('Chng_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Acct_Party_End_Dte',__NoFutureDate_valid_Acct_Party_Start_Dte',__Max_len_16_valid_Orig_Acct_Nbr',__NoFutureDate_valid_Batch_Dte',__Max_len_19_valid_Acct_Nbr',__Acpt_len_8_valid_Party_Intl_Nbr',__Acpt_value_A_U_D_space_valid_Chng_Ind']) }}
FROM CTE_3)