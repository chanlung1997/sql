CTE_3 AS (
	SELECT
	*,
	{{validate_Phone('Daytime_Phone')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('Dte_Of_Birth')}},
	{{validate_Phone('Fax_Phone')}},
	{{validate_GenderCode('Gender_Code')}},
	{{validate_IndustryCode('Industry_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_MaritalStatus('Marital_Status')}},
	{{validate_Phone('Mobile_Phone')}},
	{{validate_Phone('Nighttime_Phone')}},
	{{validate_Phone('Office_Phone')}},
	{{validate_Phone('Other_Phone')}},
	{{validate_NoFutureDate('Party_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Phone_valid_Daytime_Phone',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_Dte_Of_Birth',__Phone_valid_Fax_Phone',__GenderCode_valid_Gender_Code',__IndustryCode_valid_Industry_Code',__CountryCode_valid_Issue_Country_Code',__MaritalStatus_valid_Marital_Status',__Phone_valid_Mobile_Phone',__Phone_valid_Nighttime_Phone',__Phone_valid_Office_Phone',__Phone_valid_Other_Phone',__NoFutureDate_valid_Party_Start_Dte']) }}
FROM CTE_3)