CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Acct_Close_Dte')}},
	{{validate_NoFutureDate('Acct_Open_Dte')}},
	{{validate_01YN('Id_Doc_Present_Ind')}},
	{{validate_NoFutureDate('Acct_Status_Chng_Dte')}},
	{{validate_NoFutureDate('Cur_Prod_Start_Dte')}},
	{{validate_NoFutureDate('Last_Stmt_Dte')}},
	{{validate_NoFutureDate('Last_Trx_Dte')}},
	{{validate_NoFutureDate('Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Acct_Close_Dte',__NoFutureDate_valid_Acct_Open_Dte',__01YN_valid_Id_Doc_Present_Ind',__NoFutureDate_valid_Acct_Status_Chng_Dte',__NoFutureDate_valid_Cur_Prod_Start_Dte',__NoFutureDate_valid_Last_Stmt_Dte',__NoFutureDate_valid_Last_Trx_Dte',__NoFutureDate_valid_Start_Dte']) }}
FROM CTE_3)