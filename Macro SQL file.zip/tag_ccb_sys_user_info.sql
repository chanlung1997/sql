CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Mpf_sign_ind')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Mpf_sign_ind']) }}
FROM CTE_3)