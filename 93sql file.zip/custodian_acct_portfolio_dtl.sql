WITH  CTE_1  AS(   
SELECT 
	* 
FROM  gcp-prj-dat-bigquery-dev-00.bqd_015_raw.tag_custodian_acct_portfolio_dtl_raw 
),   
 
CTE_2  AS  ( 
SELECT
	CAST(Prod_Risk_Rating  AS  STRING)  AS  Prod_Risk_Rating,
	CAST(Qty  AS  NUMERIC)  AS  Qty,
	CAST(Qty_Being_Held  AS  NUMERIC)  AS  Qty_Being_Held,
	CAST(Share_Nature_Code  AS  STRING)  AS  Share_Nature_Code,
	CAST(Share_Nature_Desc  AS  STRING)  AS  Share_Nature_Desc,
	CAST(Share_Sub_Type_Code  AS  STRING)  AS  Share_Sub_Type_Code,
	CAST(Share_Sub_Type_Desc  AS  STRING)  AS  Share_Sub_Type_Desc,
	CAST(Share_Type_Code  AS  STRING)  AS  Share_Type_Code,
	CAST(Share_Type_Desc  AS  STRING)  AS  Share_Type_Desc,
	CAST(Stock_Name  AS  STRING)  AS  Stock_Name,
	CAST(Unit_Price  AS  NUMERIC)  AS  Unit_Price
FROM  CTE_1 
),   
 
CTE_3  AS  ( 
	SELECT   
	*,
Prod_Risk_Rating,
Qty,
Qty_Being_Held,
Share_Nature_Code,
Share_Nature_Desc,
Share_Sub_Type_Code,
Share_Sub_Type_Desc,
Share_Type_Code,
Share_Type_Desc,
Stock_Name,
Unit_Price,
	''  AS  __full_load_valid   
FROM  CTE_2 
)
 
SELECT  *  FROM  CTE_3
