CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Create_Dte')}},
	{{validate_Future_Date('Cr_Line_Close_Dte')}},
	{{validate_Future_Date('Privilage_Int_Rate_End_Dte')}},
	{{validate_NoFutureDate('Auto_Suspend_Dte')}},
	{{validate_NoFutureDate('Down_Grade_Dte')}},
	{{validate_NoFutureDate('Down_Status_Dte')}},
	{{validate_NoFutureDate('Group_Nbr_Chng_Dte')}},
	{{validate_NoFutureDate('Int_Rebate_End_Dte')}},
	{{validate_NoFutureDate('Last_Review_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Create_Dte',__Future_Date_valid_Cr_Line_Close_Dte',__Future_Date_valid_Privilage_Int_Rate_End_Dte',__NoFutureDate_valid_Auto_Suspend_Dte',__NoFutureDate_valid_Down_Grade_Dte',__NoFutureDate_valid_Down_Status_Dte',__NoFutureDate_valid_Group_Nbr_Chng_Dte',__NoFutureDate_valid_Int_Rebate_End_Dte',__NoFutureDate_valid_Last_Review_Dte']) }}
FROM CTE_3)