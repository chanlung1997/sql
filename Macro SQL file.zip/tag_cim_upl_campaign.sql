CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_NoFutureDate('Campaign_Start_Dte')}},
	{{validate_01YN('Global_Exclude_Check_Ind')}},
	{{validate_01YN('No_Acct_Check_Ind')}},
	{{validate_01YN('Optout_Check_Ind')}},
	{{validate_01YN('Recency_Check_Ind')}},
	{{validate_NoFutureDate('Update_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__NoFutureDate_valid_Campaign_Start_Dte',__01YN_valid_Global_Exclude_Check_Ind',__01YN_valid_No_Acct_Check_Ind',__01YN_valid_Optout_Check_Ind',__01YN_valid_Recency_Check_Ind',__NoFutureDate_valid_Update_Dte']) }}
FROM CTE_3)