CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Ben_Country_Code')}},
	{{validate_CountryCode('Ben_Instit_Country_Code')}},
	{{validate_CountryCode('Ext_Cust_Country_Code')}},
	{{validate_CountryCode('Instit_Country_Code')}},
	{{validate_CountryCode('Inter_Bank_Country_Code')}},
	{{validate_Max_len_10('Ben_Acct_Nbr')}},
	{{validate_Max_len_10('Other_Bank_Acct_Nbr')}},
	{{validate_Max_len_15('Related_Acct_Nbr')}},
	{{validate_Max_len_8('Stf_Nbr')}},
	{{validate_Backdate_Ind('Backdate_Ind')}},
	{{validate_Future_Date('Eff_Dte')}},
	{{validate_NoFutureDate('Credit_Dte')}},
	{{validate_CountryCode('Ultimate_Instit_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Ben_Country_Code',__CountryCode_valid_Ben_Instit_Country_Code',__CountryCode_valid_Ext_Cust_Country_Code',__CountryCode_valid_Instit_Country_Code',__CountryCode_valid_Inter_Bank_Country_Code',__Max_len_10_valid_Ben_Acct_Nbr',__Max_len_10_valid_Other_Bank_Acct_Nbr',__Max_len_15_valid_Related_Acct_Nbr',__Max_len_8_valid_Stf_Nbr',__Backdate_Ind_valid_Backdate_Ind',__Future_Date_valid_Eff_Dte',__NoFutureDate_valid_Credit_Dte',__CountryCode_valid_Ultimate_Instit_Country_Code']) }}
FROM CTE_3)