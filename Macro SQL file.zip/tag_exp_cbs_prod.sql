CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_NoFutureDate('Cbs_Prod_Start_Dte')}},
	{{validate_Future_Date('Cbs_Prod_End_Dte')}},
	{{validate_NoFutureDate('Status_Chng_Dte')}},
	{{validate_NoFutureDate('Last_Chng_Dte')}},
	{{validate_01YN('Mcy_Flag')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__NoFutureDate_valid_Cbs_Prod_Start_Dte',__Future_Date_valid_Cbs_Prod_End_Dte',__NoFutureDate_valid_Status_Chng_Dte',__NoFutureDate_valid_Last_Chng_Dte',__01YN_valid_Mcy_Flag']) }}
FROM CTE_3)