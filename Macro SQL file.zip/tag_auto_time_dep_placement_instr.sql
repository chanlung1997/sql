CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Contact_Customer_Flag')}},
	{{validate_Future_Date('Instr_End_Dte')}},
	{{validate_NoFutureDate('Instr_Create_Dte')}},
	{{validate_NoFutureDate('Instr_Modify_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Contact_Customer_Flag',__Future_Date_valid_Instr_End_Dte',__NoFutureDate_valid_Instr_Create_Dte',__NoFutureDate_valid_Instr_Modify_Dte']) }}
FROM CTE_3)