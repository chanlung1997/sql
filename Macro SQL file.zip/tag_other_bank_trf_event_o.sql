CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Ext_Cust_Country_Code')}},
	{{validate_CountryCode('Instit_Country_Code')}},
	{{validate_CountryCode('Inter_Bank_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Ext_Cust_Country_Code',__CountryCode_valid_Instit_Country_Code',__CountryCode_valid_Inter_Bank_Country_Code']) }}
FROM CTE_3)