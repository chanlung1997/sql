CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('API_Dte')}},
	{{validate_NoFutureDate('Exit_Dte')}},
	{{validate_NoFutureDate('Prev_Exit_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_API_Dte',__NoFutureDate_valid_Exit_Dte',__NoFutureDate_valid_Prev_Exit_Dte']) }}
FROM CTE_3)