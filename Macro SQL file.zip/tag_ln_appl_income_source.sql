CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Source_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Source_Country_Code']) }}
FROM CTE_3)