CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_14('Acct_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Acpt_len_74('Ref_Nbr')}},
	{{validate_NoFutureDate('Input_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_14_valid_Acct_Nbr',__NoFutureDate_valid_Batch_Dte',__Acpt_len_74_valid_Ref_Nbr',__NoFutureDate_valid_Input_Dte']) }}
FROM CTE_3)