CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_14('Other_Acct_Nbr')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_14_valid_Other_Acct_Nbr']) }}
FROM CTE_3)