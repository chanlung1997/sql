CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Card_Issue_Dte')}},
	{{validate_NoFutureDate('Cancl_Dte')}},
	{{validate_Future_Date('Eff_Dte')}},
	{{validate_Future_Date('Expiry_Dte')}},
	{{validate_NoFutureDate('First_Issue_Dte')}},
	{{validate_01YN('Chip_Card_Ind')}},
	{{validate_01YN('Upgrade_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Card_Issue_Dte',__NoFutureDate_valid_Cancl_Dte',__Future_Date_valid_Eff_Dte',__Future_Date_valid_Expiry_Dte',__NoFutureDate_valid_First_Issue_Dte',__01YN_valid_Chip_Card_Ind',__01YN_valid_Upgrade_Ind']) }}
FROM CTE_3)