CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Remitter_Acct_Nbr('Remitter_Acct_Nbr')}},
	{{validate_Party_Intl_Nbr('Party_Intl_Nbr')}},
	{{validate_Acct_Nbr('Acct_Nbr')}},
	{{validate_CountryCode('Ext_Cust_Country_Code')}},
	{{validate_NoFutureDate('Post_Dte')}},
	{{validate_CountryCode('Instit_Country_Code')}},
	{{validate_CountryCode('Inter_Bank_Country_Code')}},
	{{validate_CountryCode('IP_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Remitter_Acct_Nbr_valid_Remitter_Acct_Nbr',__Party_Intl_Nbr_valid_Party_Intl_Nbr',__Acct_Nbr_valid_Acct_Nbr',__CountryCode_valid_Ext_Cust_Country_Code',__NoFutureDate_valid_Post_Dte',__CountryCode_valid_Instit_Country_Code',__CountryCode_valid_Inter_Bank_Country_Code',__CountryCode_valid_IP_Country_Code']) }}
FROM CTE_3)