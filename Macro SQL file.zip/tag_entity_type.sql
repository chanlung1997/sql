CTE_3 AS (
	SELECT
	*,
	{{validate_Entity_Type_Desc('Entity_Type_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__Entity_Type_Desc_valid_Entity_Type_Desc']) }}
FROM CTE_3)