CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('From_Dte')}},
	{{validate_NoFutureDate('Trf_Dte')}},
	{{validate_Phone('Phone_Nbr')}},
	{{validate_Phone('Phone_Nbr_Acct_Nbr')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_From_Dte',__NoFutureDate_valid_Trf_Dte',__Phone_valid_Phone_Nbr',__Phone_valid_Phone_Nbr_Acct_Nbr']) }}
FROM CTE_3)