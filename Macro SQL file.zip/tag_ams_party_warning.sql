CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Max_len_3('Seq_Nbr')}},
	{{validate_Acpt_len_8('Party_Intl_Nbr')}},
	{{validate_Acpt_A_U_D('Chng_Ind')}},
	{{validate_NoFutureDate('Create_Dte')}},
	{{validate_Future_Date('Expiry_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Max_len_3_valid_Seq_Nbr',__Acpt_len_8_valid_Party_Intl_Nbr',__Acpt_A_U_D_valid_Chng_Ind',__NoFutureDate_valid_Create_Dte',__Future_Date_valid_Expiry_Dte']) }}
FROM CTE_3)