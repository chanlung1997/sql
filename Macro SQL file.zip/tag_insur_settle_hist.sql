CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Due_Dte')}},
	{{validate_NoFutureDate('Settle_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Due_Dte',__NoFutureDate_valid_Settle_Dte']) }}
FROM CTE_3)