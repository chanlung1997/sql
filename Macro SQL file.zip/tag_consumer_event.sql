CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Fin_Ind')}},
	{{validate_01YN('Self_Srv_Ind')}},
	{{validate_01YN('Third_Party_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Fin_Ind',__01YN_valid_Self_Srv_Ind',__01YN_valid_Third_Party_Ind']) }}
FROM CTE_3)