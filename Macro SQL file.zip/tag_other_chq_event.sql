CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Appl_Issue_Country_Code')}},
	{{validate_NoFutureDate('Last_Mod_Dte')}},
	{{validate_Max_len_11('Appl_Doc_Nbr')}},
	{{validate_Max_len_14('Acct_Nbr')}},
	{{validate_NoFutureDate('Trx_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Appl_Issue_Country_Code',__NoFutureDate_valid_Last_Mod_Dte',__Max_len_11_valid_Appl_Doc_Nbr',__Max_len_14_valid_Acct_Nbr',__NoFutureDate_valid_Trx_Dte']) }}
FROM CTE_3)