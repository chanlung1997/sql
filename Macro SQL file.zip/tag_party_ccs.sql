CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Cis_Search_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_NoFutureDate('CCRA_Dte')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_GenderCode('Gender_Code')}},
	{{validate_Phone('Home_Phone')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_MaritalStatus('Marital_Status')}},
	{{validate_Phone('Mobile_Phone')}},
	{{validate_OccupCode('Occup_Code')}},
	{{validate_Phone('Office_Phone')}},
	{{validate_Phone('Pager_Phone')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Cis_Search_Dte',__HKID_valid_Doc_Nbr',__NoFutureDate_valid_CCRA_Dte',__DocTypeCode_valid_Doc_Type_Code',__GenderCode_valid_Gender_Code',__Phone_valid_Home_Phone',__CountryCode_valid_Issue_Country_Code',__MaritalStatus_valid_Marital_Status',__Phone_valid_Mobile_Phone',__OccupCode_valid_Occup_Code',__Phone_valid_Office_Phone',__Phone_valid_Pager_Phone']) }}
FROM CTE_3)