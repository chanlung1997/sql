CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Anl_Fee_Dte')}},
	{{validate_Future_Date('Due_Dte')}},
	{{validate_NoFutureDate('Block_Trx_Dte')}},
	{{validate_NoFutureDate('High_Bal_Dte')}},
	{{validate_01YN('Cis_Ind')}},
	{{validate_01YN('Delq_Ind')}},
	{{validate_01YN('Noc_Ind')}},
	{{validate_01YN('Over_Cr_Limit_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Anl_Fee_Dte',__Future_Date_valid_Due_Dte',__NoFutureDate_valid_Block_Trx_Dte',__NoFutureDate_valid_High_Bal_Dte',__01YN_valid_Cis_Ind',__01YN_valid_Delq_Ind',__01YN_valid_Noc_Ind',__01YN_valid_Over_Cr_Limit_Ind']) }}
FROM CTE_3)