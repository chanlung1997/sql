CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Future_Date('Party_Rel_End_Dte')}},
	{{validate_01YN('Chng_Ind')}},
	{{validate_NoFutureDate('Party_Rel_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Future_Date_valid_Party_Rel_End_Dte',__01YN_valid_Chng_Ind',__NoFutureDate_valid_Party_Rel_Start_Dte']) }}
FROM CTE_3)