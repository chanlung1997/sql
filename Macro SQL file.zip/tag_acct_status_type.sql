CTE_3 AS (
	SELECT
	*,
	{{validate_Acct_Status_Type_Desc('Acct_Status_Type_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__Acct_Status_Type_Desc_valid_Acct_Status_Type_Desc']) }}
FROM CTE_3)