CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_20('Remitter_Acct_Nbr')}},
	{{validate_Max_len_16('Orig_Acct_Nbr')}},
	{{validate_Max_len_19('Acct_Nbr')}},
	{{validate_Max_len_14('Ben_Acct_Nbr')}},
	{{validate_Max_len_6('Chq_Nbr')}},
	{{validate_Max_len_8('Party_Intl_Nbr')}},
	{{validate_Max_len_15('Other_Acct_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_CountryCode('Ext_Cust_Country_Code')}},
	{{validate_NoFutureDate('Post_Dte')}},
	{{validate_CountryCode('Instit_Country_Code')}},
	{{validate_CountryCode('Inter_Bank_Country_Code')}},
	{{validate_CountryCode('IP_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_20_valid_Remitter_Acct_Nbr',__Max_len_16_valid_Orig_Acct_Nbr',__Max_len_19_valid_Acct_Nbr',__Max_len_14_valid_Ben_Acct_Nbr',__Max_len_6_valid_Chq_Nbr',__Max_len_8_valid_Party_Intl_Nbr',__Max_len_15_valid_Other_Acct_Nbr',__NoFutureDate_valid_Batch_Dte',__CountryCode_valid_Ext_Cust_Country_Code',__NoFutureDate_valid_Post_Dte',__CountryCode_valid_Instit_Country_Code',__CountryCode_valid_Inter_Bank_Country_Code',__CountryCode_valid_IP_Country_Code']) }}
FROM CTE_3)