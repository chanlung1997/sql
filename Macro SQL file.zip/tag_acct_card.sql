CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Cancl_Dte')}},
	{{validate_Future_Date('Atm_Linked_Dte')}},
	{{validate_Future_Date('Expiry_Dte')}},
	{{validate_01YN('Primary_Acct_Ind')}},
	{{validate_01YN('Supp_Card_Use_Ind')}},
	{{validate_NoFutureDate('Atm_Actvn_Dte')}},
	{{validate_NoFutureDate('Card_Issue_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Cancl_Dte',__Future_Date_valid_Atm_Linked_Dte',__Future_Date_valid_Expiry_Dte',__01YN_valid_Primary_Acct_Ind',__01YN_valid_Supp_Card_Use_Ind',__NoFutureDate_valid_Atm_Actvn_Dte',__NoFutureDate_valid_Card_Issue_Dte']) }}
FROM CTE_3)