CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Asset_Liab_Ref_Rate_Basis_Flag')}},
	{{validate_NoAlphas('Backdate_Amt_HKD')}},
	{{validate_01YNYesNo('Backdate_Tx_Flag')}},
	{{validate_NoFutureDate('Backdate_Tx_From_Date')}},
	{{validate_NoFutureDate('Backdate_Tx_To_Date')}},
	{{validate_01YN('Capped_rate_flag')}},
	{{validate_01YN('Compare_rate_flag')}},
	{{validate_NoFutureDate('IFP_Processing_Date')}},
	{{validate_01YN('Fixed_Rate_flag')}},
	{{validate_01YN('Revolving_flag')}},
	{{validate_01YNYesNo('Scheduled_PPL_Repay_Flag')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Asset_Liab_Ref_Rate_Basis_Flag',__NoAlphas_valid_Backdate_Amt_HKD',__01YNYesNo_valid_Backdate_Tx_Flag',__NoFutureDate_valid_Backdate_Tx_From_Date',__NoFutureDate_valid_Backdate_Tx_To_Date',__01YN_valid_Capped_rate_flag',__01YN_valid_Compare_rate_flag',__NoFutureDate_valid_IFP_Processing_Date',__01YN_valid_Fixed_Rate_flag',__01YN_valid_Revolving_flag',__01YNYesNo_valid_Scheduled_PPL_Repay_Flag']) }}
FROM CTE_3)