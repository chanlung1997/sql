CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Country_Code')}},
	{{validate_01YN('Chin_Eng_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Country_Code',__01YN_valid_Chin_Eng_Ind']) }}
FROM CTE_3)