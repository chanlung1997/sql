CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Max_len_3('Seq_Nbr')}},
	{{validate_Acpt_len_8('Party_Intl_Nbr')}},
	{{validate_Acpt_A_U_D('Chng_Ind')}},
	{{validate_CountryCode('Country_Code')}},
	{{validate_Acpt_value_N_Y_space('Permanent_Add_Ind')}},
	{{validate_HKPhoneAreaCode('Phone_Area_Code')}},
	{{validate_PhoneTypeCode('Phone_Type_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Max_len_3_valid_Seq_Nbr',__Acpt_len_8_valid_Party_Intl_Nbr',__Acpt_A_U_D_valid_Chng_Ind',__CountryCode_valid_Country_Code',__Acpt_value_N_Y_space_valid_Permanent_Add_Ind',__HKPhoneAreaCode_valid_Phone_Area_Code',__PhoneTypeCode_valid_Phone_Type_Desc']) }}
FROM CTE_3)