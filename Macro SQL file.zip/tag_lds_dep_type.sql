CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Orig_Maturity_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Orig_Maturity_Dte']) }}
FROM CTE_3)