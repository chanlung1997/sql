CREATE  OR  REPLACE  TABLE  `bqd_015_raw.tag_custodian_acct_portfolio_dtl_raw`  (
Prod_Risk_Rating  STRING(1),
Qty  STRING(15),
Qty_Being_Held  STRING(15),
Share_Nature_Code  STRING(2),
Share_Nature_Desc  STRING(5),
Share_Sub_Type_Code  STRING(5),
Share_Sub_Type_Desc  STRING(40),
Share_Type_Code  STRING(2),
Share_Type_Desc  STRING(20),
Stock_Name  STRING(40),
Unit_Price  STRING(13),
__batch_date  TIMESTAMP,   
__load_date  TIMESTAMP,   
__file_name  STRING,   
__load_type  STRING,   
__sys_code  STRING,   
__row_number  STRING 
);
