CTE_3 AS (
	SELECT
	*,
	{{validate_GenderCode('Gender_Code')}},
	{{validate_GenderCode('Gender_Code_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__GenderCode_valid_Gender_Code',__GenderCode_valid_Gender_Code_Desc']) }}
FROM CTE_3)