CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Asset_Liab_Classif_Flag')}},
	{{validate_01YN('Asset_Liab_Ref_Rate_Basis_Flag')}},
	{{validate_NoAlphas('Backdate_Amt_Hkd')}},
	{{validate_01YNYesNo('Backdate_Tx_Flag')}},
	{{validate_NoFutureDate('Backdate_Tx_From_Date')}},
	{{validate_NoFutureDate('Backdate_Tx_To_Date')}},
	{{validate_NoFutureDate('IFP_Processing_Date')}},
	{{validate_01YN('Liquidity_Mgt_Asset_Liab_Flag')}},
	{{validate_01YN('SWAP_Hedged_Flag')}},
	{{validate_01YN('TMD_Asset_Liab_Owner_Flag')}},
	{{validate_01YN('Trade_Date_Bal_Flag')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Asset_Liab_Classif_Flag',__01YN_valid_Asset_Liab_Ref_Rate_Basis_Flag',__NoAlphas_valid_Backdate_Amt_Hkd',__01YNYesNo_valid_Backdate_Tx_Flag',__NoFutureDate_valid_Backdate_Tx_From_Date',__NoFutureDate_valid_Backdate_Tx_To_Date',__NoFutureDate_valid_IFP_Processing_Date',__01YN_valid_Liquidity_Mgt_Asset_Liab_Flag',__01YN_valid_SWAP_Hedged_Flag',__01YN_valid_TMD_Asset_Liab_Owner_Flag',__01YN_valid_Trade_Date_Bal_Flag']) }}
FROM CTE_3)