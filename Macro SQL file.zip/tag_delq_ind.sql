CTE_3 AS (
	SELECT
	*,
	{{validate_DELQ_IND('Delq_Ind_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__DELQ_IND_valid_Delq_Ind_Desc']) }}
FROM CTE_3)