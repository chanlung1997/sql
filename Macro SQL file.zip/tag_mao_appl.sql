CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Corr_Add_Country_Code')}},
	{{validate_NoFutureDate('Create_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('Dte_Of_Birth')}},
	{{validate_Max_len_14('Acct_Nbr')}},
	{{validate_Max_len_16('Supp_Doc_Nbr')}},
	{{validate_Corr_Add_Type('Corr_Add_Type')}},
	{{validate_Appl_Type('Appl_Type')}},
	{{validate_Future_Date('Doc_Expiry_Dte')}},
	{{validate_Future_Date('Supp_Doc_Expiry_Dte')}},
	{{validate_NoFutureDate('API_Dte')}},
	{{validate_IndustryCode('Industry_Code')}},
	{{validate_OccupCode('Occup_Code')}},
	{{validate_NoFutureDate('Session_Dte')}},
	{{validate_NoFutureDate('Submit_Dte')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_PhoneCountryCode('Mobile_Phone_Country_Code')}},
	{{validate_Phone('Mobile_Phone_Nbr')}},
	{{validate_Email('Optout_Email')}},
	{{validate_PhoneCountryCode('Residential_Phone_Country_Code')}},
	{{validate_Phone('Residential_Phone_Nbr')}},
	{{validate_CountryCode('Supp_Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Corr_Add_Country_Code',__NoFutureDate_valid_Create_Dte',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_Dte_Of_Birth',__Max_len_14_valid_Acct_Nbr',__Max_len_16_valid_Supp_Doc_Nbr',__Corr_Add_Type_valid_Corr_Add_Type',__Appl_Type_valid_Appl_Type',__Future_Date_valid_Doc_Expiry_Dte',__Future_Date_valid_Supp_Doc_Expiry_Dte',__NoFutureDate_valid_API_Dte',__IndustryCode_valid_Industry_Code',__OccupCode_valid_Occup_Code',__NoFutureDate_valid_Session_Dte',__NoFutureDate_valid_Submit_Dte',__CountryCode_valid_Issue_Country_Code',__PhoneCountryCode_valid_Mobile_Phone_Country_Code',__Phone_valid_Mobile_Phone_Nbr',__Email_valid_Optout_Email',__PhoneCountryCode_valid_Residential_Phone_Country_Code',__Phone_valid_Residential_Phone_Nbr',__CountryCode_valid_Supp_Issue_Country_Code']) }}
FROM CTE_3)