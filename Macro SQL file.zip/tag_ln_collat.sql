CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Collat_Purchase_Dte')}},
	{{validate_Future_Date('Collat_Val_Dte')}},
	{{validate_NoFutureDate('Hkmc_Val_Dte')}},
	{{validate_NoFutureDate('Ppty_Last_Assign_Dte')}},
	{{validate_NoFutureDate('Reconstruct_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Collat_Purchase_Dte',__Future_Date_valid_Collat_Val_Dte',__NoFutureDate_valid_Hkmc_Val_Dte',__NoFutureDate_valid_Ppty_Last_Assign_Dte',__NoFutureDate_valid_Reconstruct_Dte']) }}
FROM CTE_3)