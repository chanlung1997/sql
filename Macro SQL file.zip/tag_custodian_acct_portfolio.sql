CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('start_dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_start_dte']) }}
FROM CTE_3)