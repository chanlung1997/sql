CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_18('Int_Acct_Nbr')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_18_valid_Int_Acct_Nbr']) }}
FROM CTE_3)