CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Delete_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Delete_Dte']) }}
FROM CTE_3)