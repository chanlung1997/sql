CTE_3 AS (
	SELECT
	*,
	{{validate_Acpt_len_4to14('Acct_Nbr')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_01YN('Acct_In_Out_Scope_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__Acpt_len_4to14_valid_Acct_Nbr',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code',__01YN_valid_Acct_In_Out_Scope_Ind']) }}
FROM CTE_3)