CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_19('Acct_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Acpt_A_U_D('Chng_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_19_valid_Acct_Nbr',__NoFutureDate_valid_Batch_Dte',__Acpt_A_U_D_valid_Chng_Ind']) }}
FROM CTE_3)