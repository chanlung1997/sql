CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_NoFutureDate('Cmple_Dte')}},
	{{validate_NoFutureDate('HKMC_Valuation_Dte')}},
	{{validate_NoFutureDate('Chrg_Code_Chng_Dte')}},
	{{validate_NoFutureDate('Est_Val_Dte')}},
	{{validate_NoFutureDate('Foresale_Val_Dte')}},
	{{validate_NoFutureDate('Lease_Term_Comm_Dte')}},
	{{validate_NoFutureDate('Net_Realz_Val_Dte')}},
	{{validate_NoFutureDate('Occup_Permit_Dte')}},
	{{validate_NoFutureDate('Portfolio_Val_Dte')}},
	{{validate_NoFutureDate('Purchase_Dte')}},
	{{validate_NoFutureDate('Reconstruct_Val_Dte')}},
	{{validate_CountryCode('Ppty_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__NoFutureDate_valid_Cmple_Dte',__NoFutureDate_valid_HKMC_Valuation_Dte',__NoFutureDate_valid_Chrg_Code_Chng_Dte',__NoFutureDate_valid_Est_Val_Dte',__NoFutureDate_valid_Foresale_Val_Dte',__NoFutureDate_valid_Lease_Term_Comm_Dte',__NoFutureDate_valid_Net_Realz_Val_Dte',__NoFutureDate_valid_Occup_Permit_Dte',__NoFutureDate_valid_Portfolio_Val_Dte',__NoFutureDate_valid_Purchase_Dte',__NoFutureDate_valid_Reconstruct_Val_Dte',__CountryCode_valid_Ppty_Country_Code']) }}
FROM CTE_3)