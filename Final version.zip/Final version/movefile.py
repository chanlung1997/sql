import fnmatch
import shutil
import os 
import openpyxl as op
wb = op.load_workbook(r"C:\Users\Derek\OneDrive - sagetech.com.hk\Desktop\GIT\testing\datastan_batch1_20221123.xlsx")

sheet = wb.sheetnames
for file in os.listdir(r'C:\Users\Derek\OneDrive - sagetech.com.hk\Desktop\GIT\sql'):
    if file.startswith('tag'):
        if file[4:-4].upper() in sheet:
            shutil.move("C:\\Users\\Derek\\OneDrive - sagetech.com.hk\\Desktop\\GIT\\sql\\"+file, "C:\\Users\\Derek\\OneDrive - sagetech.com.hk\\Desktop\\GIT\\sql\\policytags\\"+file)
    else:
        pass
