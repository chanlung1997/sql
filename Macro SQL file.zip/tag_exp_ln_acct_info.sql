CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Future_Date('Dr_Note_Val_Dte')}},
	{{validate_Future_Date('First_Pmt_Dte')}},
	{{validate_Future_Date('Ln_Risk_Review_Dte')}},
	{{validate_NoFutureDate('Reschd_Approv_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Future_Date_valid_Dr_Note_Val_Dte',__Future_Date_valid_First_Pmt_Dte',__Future_Date_valid_Ln_Risk_Review_Dte',__NoFutureDate_valid_Reschd_Approv_Dte']) }}
FROM CTE_3)