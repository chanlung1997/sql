CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('DnGrade_Dte')}},
	{{validate_NoFutureDate('UpGrade_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_DnGrade_Dte',__NoFutureDate_valid_UpGrade_Dte']) }}
FROM CTE_3)