CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Local_China_Overseas_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Local_China_Overseas_Ind']) }}
FROM CTE_3)