import openpyxl as op 

wb_datastan = op.load_workbook(r"C:\\Users\\Derek\\OneDrive - sagetech.com.hk\\Desktop\\GIT\\sql\\datastan_batch1_20230113_prod.xlsx")
wb_macro = op.load_workbook(r"C:\\Users\Derek\\OneDrive - sagetech.com.hk\Desktop\\GIT\\macro_rule_20221123.xlsx")
wb_unmatch = op.load_workbook(r"C:\\Users\\Derek\\OneDrive - sagetech.com.hk\\Desktop\\GIT\\unmatch column.xlsx")

# sheet_data = wb_datastan.sheetnames
sheet_unmatch_nm = wb_unmatch.sheetnames
st_datastan = wb_datastan[sheet_unmatch_nm[1]]
macro_sheet = wb_macro["Model"]
print(st_datastan)
print(len(sheet_unmatch_nm))

for name in range(0,len(sheet_unmatch_nm)):
    target_table = sheet_unmatch_nm[name]
    print(type(target_table))
    st_datastan = wb_datastan[sheet_unmatch_nm[name]]
    print(st_datastan)
    for i in range(1,st_datastan.max_row+1):
        if target_table == macro_sheet.cell(row=i, column=1).value:
            if macro_sheet.cell(row=i, column=2).value == 