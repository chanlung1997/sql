CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Create_Dte')}},
	{{validate_Juris_Sts_Update_Centre_Id('Juris_Sts_Update_Centre_Id')}},
	{{validate_NoFutureDate('Doc_Issue_Country_LMDte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('Add_POO_LMDte')}},
	{{validate_NoFutureDate('Ctrl_Person_Sole_Propr_LMDte')}},
	{{validate_NoFutureDate('Juris_Sts_Update_dte')}},
	{{validate_NoFutureDate('PASA_LMDte')}},
	{{validate_NoFutureDate('Place_Of_Origin_LMDte')}},
	{{validate_NoFutureDate('Sole_Props_LMDte')}},
	{{validate_NoFutureDate('Trx_Dte')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_CountryCode('Juris_Country_Code')}},
	{{validate_NoFutureDate('Last_Update_Dte')}},
	{{validate_01YN('Add_POO_Ind')}},
	{{validate_01YN('Ctrl_Person_Sole_Propr_Ind')}},
	{{validate_01YN('In_Care_Of_Hold_Mail_Ind')}},
	{{validate_01YN('PASA_Ind')}},
	{{validate_01YN('Place_Of_Origin_Ind')}},
	{{validate_01YN('SI_Ind')}},
	{{validate_01YN('Sole_Props_Ind')}},
	{{validate_NoFutureDate('Phone_Nbr_LMDte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Create_Dte',__Juris_Sts_Update_Centre_Id_valid_Juris_Sts_Update_Centre_Id',__NoFutureDate_valid_Doc_Issue_Country_LMDte',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_Add_POO_LMDte',__NoFutureDate_valid_Ctrl_Person_Sole_Propr_LMDte',__NoFutureDate_valid_Juris_Sts_Update_dte',__NoFutureDate_valid_PASA_LMDte',__NoFutureDate_valid_Place_Of_Origin_LMDte',__NoFutureDate_valid_Sole_Props_LMDte',__NoFutureDate_valid_Trx_Dte',__CountryCode_valid_Issue_Country_Code',__CountryCode_valid_Juris_Country_Code',__NoFutureDate_valid_Last_Update_Dte',__01YN_valid_Add_POO_Ind',__01YN_valid_Ctrl_Person_Sole_Propr_Ind',__01YN_valid_In_Care_Of_Hold_Mail_Ind',__01YN_valid_PASA_Ind',__01YN_valid_Place_Of_Origin_Ind',__01YN_valid_SI_Ind',__01YN_valid_Sole_Props_Ind',__NoFutureDate_valid_Phone_Nbr_LMDte']) }}
FROM CTE_3)