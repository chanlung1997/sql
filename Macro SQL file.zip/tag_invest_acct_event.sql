CTE_3 AS (
	SELECT
	*,
	{{validate_Acpt_len_6_14_15('Acct_Nbr')}},
	{{validate_Event_Type_8items('Event_Type')}}
FROM CTE_2
),
{{ full_valid_flag([__Acpt_len_6_14_15_valid_Acct_Nbr',__Event_Type_8items_valid_Event_Type']) }}
FROM CTE_3)