CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Country_Code']) }}
FROM CTE_3)