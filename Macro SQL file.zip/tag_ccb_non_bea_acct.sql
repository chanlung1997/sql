CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Ccb_Chats_Ind')}},
	{{validate_01YN('Ccb_Ecg_Ind')}},
	{{validate_01YN('Ccb_Lc_Ind')}},
	{{validate_01YN('Ccb_Tt_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Ccb_Chats_Ind',__01YN_valid_Ccb_Ecg_Ind',__01YN_valid_Ccb_Lc_Ind',__01YN_valid_Ccb_Tt_Ind']) }}
FROM CTE_3)