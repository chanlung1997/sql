CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Approve_Dte')}},
	{{validate_NoFutureDate('Create_Dte')}},
	{{validate_NoFutureDate('Last_Update_Dte')}},
	{{validate_01YN('Risk_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Approve_Dte',__NoFutureDate_valid_Create_Dte',__NoFutureDate_valid_Last_Update_Dte',__01YN_valid_Risk_Ind']) }}
FROM CTE_3)