CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Actv_Type('Actv_Type')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Actv_Type_valid_Actv_Type']) }}
FROM CTE_3)