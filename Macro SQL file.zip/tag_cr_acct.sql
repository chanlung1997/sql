CTE_3 AS (
	SELECT
	*,
	{{validate_CountryCode('Analysis_By_Country_Code')}},
	{{validate_NoFutureDate('Int_Susp_Dte')}},
	{{validate_01YN('Impair_Ind')}},
	{{validate_01YN('Mid_Mth_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__CountryCode_valid_Analysis_By_Country_Code',__NoFutureDate_valid_Int_Susp_Dte',__01YN_valid_Impair_Ind',__01YN_valid_Mid_Mth_Ind']) }}
FROM CTE_3)