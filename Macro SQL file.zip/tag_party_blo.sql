CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Cis_Search_Dte')}},
	{{validate_Future_Date('BEA_Consent_Recd_Dte')}},
	{{validate_Future_Date('Doc_Expiry_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_Future_Date('Party_End_Dte')}},
	{{validate_NoFutureDate('BEA_Wd_Req_Dte')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('Incorporation_Dte')}},
	{{validate_NoFutureDate('Dte_Of_Birth')}},
	{{validate_GenderCode('Gender_Code')}},
	{{validate_IndustryCode('Industry_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_MaritalStatus('Marital_Status')}},
	{{validate_OccupCode('Occup_Code')}},
	{{validate_NoFutureDate('Party_Start_Dte')}},
	{{validate_TitleCode('Title_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Cis_Search_Dte',__Future_Date_valid_BEA_Consent_Recd_Dte',__Future_Date_valid_Doc_Expiry_Dte',__HKID_valid_Doc_Nbr',__Future_Date_valid_Party_End_Dte',__NoFutureDate_valid_BEA_Wd_Req_Dte',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_Incorporation_Dte',__NoFutureDate_valid_Dte_Of_Birth',__GenderCode_valid_Gender_Code',__IndustryCode_valid_Industry_Code',__CountryCode_valid_Issue_Country_Code',__MaritalStatus_valid_Marital_Status',__OccupCode_valid_Occup_Code',__NoFutureDate_valid_Party_Start_Dte',__TitleCode_valid_Title_Code']) }}
FROM CTE_3)