CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Cis_Search_Dte')}},
	{{validate_NoFutureDate('Doc_Issue_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_Future_Date('Doc_Expiry_Dte')}},
	{{validate_Future_Date('Party_End_Dte')}},
	{{validate_IndustryCode('Industry_Code')}},
	{{validate_NoFutureDate('Party_Start_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Cis_Search_Dte',__NoFutureDate_valid_Doc_Issue_Dte',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__CountryCode_valid_Issue_Country_Code',__Future_Date_valid_Doc_Expiry_Dte',__Future_Date_valid_Party_End_Dte',__IndustryCode_valid_Industry_Code',__NoFutureDate_valid_Party_Start_Dte']) }}
FROM CTE_3)