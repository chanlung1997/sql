CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Occup_Permit_Dte')}},
	{{validate_Future_Date('Purchase_Dte')}},
	{{validate_NoFutureDate('First_Assignment_Dte')}},
	{{validate_NoFutureDate('Prev_Purchase_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Occup_Permit_Dte',__Future_Date_valid_Purchase_Dte',__NoFutureDate_valid_First_Assignment_Dte',__NoFutureDate_valid_Prev_Purchase_Dte']) }}
FROM CTE_3)