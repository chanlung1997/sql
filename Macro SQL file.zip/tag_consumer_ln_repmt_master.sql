CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Insl_Amt_Settlement_Dte')}},
	{{validate_Future_Date('Odue_Penalty_Settlement_Dte')}},
	{{validate_Future_Date('Pmt_Due_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Insl_Amt_Settlement_Dte',__Future_Date_valid_Odue_Penalty_Settlement_Dte',__Future_Date_valid_Pmt_Due_Dte']) }}
FROM CTE_3)