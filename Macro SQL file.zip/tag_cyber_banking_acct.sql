CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Acct_Aggr_Fn_Last_Update_Dte')}},
	{{validate_NoFutureDate('Bill_Pmt_Fn_Last_Update_Dte')}},
	{{validate_NoFutureDate('Tfr_Fn_Last_Update_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Acct_Aggr_Fn_Last_Update_Dte',__NoFutureDate_valid_Bill_Pmt_Fn_Last_Update_Dte',__NoFutureDate_valid_Tfr_Fn_Last_Update_Dte']) }}
FROM CTE_3)