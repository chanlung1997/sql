CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Last_Replenish_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Last_Replenish_Dte']) }}
FROM CTE_3)