CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Create_Date')}},
	{{validate_NoFutureDate('Update_Date')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Create_Date',__NoFutureDate_valid_Update_Date']) }}
FROM CTE_3)