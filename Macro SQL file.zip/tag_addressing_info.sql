CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_15('Acct_Nbr')}},
	{{validate_Cust_Type('Cust_Type')}},
	{{validate_Acpt_value_RTOP_space('Support_Type')}},
	{{validate_Future_Date('Reg_Dte')}},
	{{validate_01YN('Default_Ind')}},
	{{validate_01YN('Pending_Eff_Ind')}},
	{{validate_NoFutureDate('Last_Update_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_15_valid_Acct_Nbr',__Cust_Type_valid_Cust_Type',__Acpt_value_RTOP_space_valid_Support_Type',__Future_Date_valid_Reg_Dte',__01YN_valid_Default_Ind',__01YN_valid_Pending_Eff_Ind',__NoFutureDate_valid_Last_Update_Dte']) }}
FROM CTE_3)