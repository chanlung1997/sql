CTE_3 AS (
	SELECT
	*,
	{{validate_01YN('Dep_Acct_Ind')}},
	{{validate_01YN('Ln_Acct_Ind')}}
FROM CTE_2
),
{{ full_valid_flag([__01YN_valid_Dep_Acct_Ind',__01YN_valid_Ln_Acct_Ind']) }}
FROM CTE_3)