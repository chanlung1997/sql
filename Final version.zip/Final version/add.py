import openpyxl as op

wb = op.load_workbook(r"C:\Users\Derek\OneDrive - sagetech.com.hk\Desktop\GIT\testing\datastan_batch1_20221123.xlsx")


for sheet in wb:
    for i in range(1,sheet.max_row):
        f = sheet.cell(row=i, column=6).value
#        g = sheet.cell(row=i, column=7).value
        if f =="DATE":
            sheet.cell(row=i, column=7).value= 8
wb.save("datastan_batch1_20221123.xlsx")




