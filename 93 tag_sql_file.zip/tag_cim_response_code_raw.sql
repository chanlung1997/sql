CREATE  OR  REPLACE  TABLE  `bqd_015_raw.tag_cim_response_code_raw`  (
Campaign_Class  STRING(10),
Response_Code  STRING(4),
Response_Desc  STRING(100),
Response_Status_Code  STRING(2),
Response_Status_Desc  STRING(50),
__batch_date  TIMESTAMP,   
__load_date  TIMESTAMP,   
__file_name  STRING,   
__load_type  STRING,   
__sys_code  STRING,   
__row_number  STRING 
);
