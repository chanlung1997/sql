CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Lease_Term_Expiry_Dte')}},
	{{validate_Future_Date('Occup_Permit_Dte')}},
	{{validate_NoFutureDate('Lease_Term_Comm_Dte')}},
	{{validate_CountryCode('Ppty_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Lease_Term_Expiry_Dte',__Future_Date_valid_Occup_Permit_Dte',__NoFutureDate_valid_Lease_Term_Comm_Dte',__CountryCode_valid_Ppty_Country_Code']) }}
FROM CTE_3)