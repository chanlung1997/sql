CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Aprov_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Aprov_Dte']) }}
FROM CTE_3)