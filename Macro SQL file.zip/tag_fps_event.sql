CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_10('Bill_Nbr')}},
	{{validate_Max_len_10('Related_Acct_Nbr')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_10_valid_Bill_Nbr',__Max_len_10_valid_Related_Acct_Nbr']) }}
FROM CTE_3)