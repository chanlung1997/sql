CTE_3 AS (
	SELECT
	*,
	{{validate_01YNYesNo('Flg_Backdate')}}
FROM CTE_2
),
{{ full_valid_flag([__01YNYesNo_valid_Flg_Backdate']) }}
FROM CTE_3)