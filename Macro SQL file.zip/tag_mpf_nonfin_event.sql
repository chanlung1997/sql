CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Confirmed_Dte')}},
	{{validate_Future_Date('Cover_Fr_Dte')}},
	{{validate_Future_Date('Cover_To_Dte')}},
	{{validate_Future_Date('Eff_Dte')}},
	{{validate_Future_Date('To_Scheme_Dte')}},
	{{validate_NoFutureDate('Contrib_Upto_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Confirmed_Dte',__Future_Date_valid_Cover_Fr_Dte',__Future_Date_valid_Cover_To_Dte',__Future_Date_valid_Eff_Dte',__Future_Date_valid_To_Scheme_Dte',__NoFutureDate_valid_Contrib_Upto_Dte']) }}
FROM CTE_3)