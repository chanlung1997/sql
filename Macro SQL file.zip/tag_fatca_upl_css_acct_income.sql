CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_20('Trf_Ref_Nbr')}},
	{{validate_Max_len_15('Acct_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Acpt_len_51_52('Ref_Nbr')}},
	{{validate_NoFutureDate('Input_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_20_valid_Trf_Ref_Nbr',__Max_len_15_valid_Acct_Nbr',__NoFutureDate_valid_Batch_Dte',__Acpt_len_51_52_valid_Ref_Nbr',__NoFutureDate_valid_Input_Dte']) }}
FROM CTE_3)