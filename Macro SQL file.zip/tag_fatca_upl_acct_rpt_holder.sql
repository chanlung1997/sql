CTE_3 AS (
	SELECT
	*,
	{{validate_Max_len_15('Doc_Nbr')}},
	{{validate_CountryCode('Add_Country_Code')}},
	{{validate_Max_len_19('Ref_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_NoFutureDate('Birth_Dte')}},
	{{validate_NoFutureDate('Input_Dte')}},
	{{validate_CountryCode('Issue_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Max_len_15_valid_Doc_Nbr',__CountryCode_valid_Add_Country_Code',__Max_len_19_valid_Ref_Nbr',__NoFutureDate_valid_Batch_Dte',__NoFutureDate_valid_Birth_Dte',__NoFutureDate_valid_Input_Dte',__CountryCode_valid_Issue_Country_Code']) }}
FROM CTE_3)