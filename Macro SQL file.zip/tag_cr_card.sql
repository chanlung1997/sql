CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Card_Issue_Dte')}},
	{{validate_01YN('Actvn_Flag')}},
	{{validate_Future_Date('Card_Coll_Dte')}},
	{{validate_Future_Date('Expiry_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Card_Issue_Dte',__01YN_valid_Actvn_Flag',__Future_Date_valid_Card_Coll_Dte',__Future_Date_valid_Expiry_Dte']) }}
FROM CTE_3)