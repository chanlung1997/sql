CTE_3 AS (
	SELECT
	*,
	{{validate_Acpt_len_18_null('Mandate_Nbr')}},
	{{validate_Future_Date('CNY_Corp_Next_Review_Dte')}},
	{{validate_NoFutureDate('Acct_Preopen_Dte')}},
	{{validate_NoFutureDate('Dormant_Dte')}},
	{{validate_NoFutureDate('Last_Dep_Dte')}},
	{{validate_NoFutureDate('Last_Wd_Dte')}},
	{{validate_NoFutureDate('Reactvn_Dte')}},
	{{validate_NoFutureDate('SGP_Last_Update_Dte')}},
	{{validate_NoFutureDate('WMC_Last_Update_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Acpt_len_18_null_valid_Mandate_Nbr',__Future_Date_valid_CNY_Corp_Next_Review_Dte',__NoFutureDate_valid_Acct_Preopen_Dte',__NoFutureDate_valid_Dormant_Dte',__NoFutureDate_valid_Last_Dep_Dte',__NoFutureDate_valid_Last_Wd_Dte',__NoFutureDate_valid_Reactvn_Dte',__NoFutureDate_valid_SGP_Last_Update_Dte',__NoFutureDate_valid_WMC_Last_Update_Dte']) }}
FROM CTE_3)