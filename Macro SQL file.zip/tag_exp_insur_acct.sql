CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Future_Date('Expiry_Dte')}},
	{{validate_NoFutureDate('Policy_Issue_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Future_Date_valid_Expiry_Dte',__NoFutureDate_valid_Policy_Issue_Dte']) }}
FROM CTE_3)