CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Val_Dte')}},
	{{validate_CountryCode('Event_Country_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Val_Dte',__CountryCode_valid_Event_Country_Code']) }}
FROM CTE_3)