CREATE  OR  REPLACE  TABLE  `bqd_015_raw.tag_prod_subtype_raw`  (
Prod_Subtype_Code  STRING(6),
Prod_Subtype_Desc  STRING(30),
Prod_Type_Code  STRING(3),
__batch_date  TIMESTAMP,   
__load_date  TIMESTAMP,   
__file_name  STRING,   
__load_type  STRING,   
__sys_code  STRING,   
__row_number  STRING 
);
