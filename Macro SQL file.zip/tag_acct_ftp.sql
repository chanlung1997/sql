CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Acct_Open_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Acct_Open_Dte']) }}
FROM CTE_3)