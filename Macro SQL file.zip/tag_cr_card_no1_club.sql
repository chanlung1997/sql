CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Expiry_Dte')}},
	{{validate_NoFutureDate('Prev_Expiry_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Expiry_Dte',__NoFutureDate_valid_Prev_Expiry_Dte']) }}
FROM CTE_3)