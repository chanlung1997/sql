CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Acct_Close_Dte')}},
	{{validate_NoFutureDate('Acct_Open_Dte')}},
	{{validate_Max_len_16('Orig_Acct_Nbr')}},
	{{validate_Max_len_19('Acct_Nbr')}},
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Acpt_A_U_D('Chng_Ind')}},
	{{validate_CountryCode('Country_Code')}},
	{{validate_Acct_Ind_ACCT('Acct_Ind')}},
	{{validate_NoFutureDate('Reactvn_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Acct_Close_Dte',__NoFutureDate_valid_Acct_Open_Dte',__Max_len_16_valid_Orig_Acct_Nbr',__Max_len_19_valid_Acct_Nbr',__NoFutureDate_valid_Batch_Dte',__Acpt_A_U_D_valid_Chng_Ind',__CountryCode_valid_Country_Code',__Acct_Ind_ACCT_valid_Acct_Ind',__NoFutureDate_valid_Reactvn_Dte']) }}
FROM CTE_3)