CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('Due_Dte')}},
	{{validate_Future_Date('Pmt_Due_Dte')}},
	{{validate_NoFutureDate('Drawdn_Dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_Due_Dte',__Future_Date_valid_Pmt_Due_Dte',__NoFutureDate_valid_Drawdn_Dte']) }}
FROM CTE_3)