CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_OccupCode('Occup_Code')}},
	{{validate_OccupCode('Old_Occup_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__OccupCode_valid_Occup_Code',__OccupCode_valid_Old_Occup_Code']) }}
FROM CTE_3)