CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Acct_Close_Dte')}},
	{{validate_NoFutureDate('Acct_Open_Dte')}},
	{{validate_Phone('Home_Phone')}},
	{{validate_Phone('Mobile_Phone')}},
	{{validate_01YN('Universal_Cntl_Group_Ind')}},
	{{validate_Phone('Office_Phone')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Acct_Close_Dte',__NoFutureDate_valid_Acct_Open_Dte',__Phone_valid_Home_Phone',__Phone_valid_Mobile_Phone',__01YN_valid_Universal_Cntl_Group_Ind',__Phone_valid_Office_Phone']) }}
FROM CTE_3)