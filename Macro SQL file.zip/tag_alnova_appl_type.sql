CTE_3 AS (
	SELECT
	*,
	{{validate_Appl_Type_Desc('Appl_Type_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__Appl_Type_Desc_valid_Appl_Type_Desc']) }}
FROM CTE_3)