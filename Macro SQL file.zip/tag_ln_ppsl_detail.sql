CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('First_Assignment_dte')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_First_Assignment_dte']) }}
FROM CTE_3)