CTE_3 AS (
	SELECT
	*,
	{{validate_NoFutureDate('Batch_Dte')}},
	{{validate_Acpt_len_8('Party_Intl_Nbr')}},
	{{validate_Acpt_A_U('Chng_Ind')}},
	{{validate_Acpt_value_Y_space('Staff_Ind')}},
	{{validate_Party_Type_Desc('Party_Type_Desc')}},
	{{validate_Acpt_len_2('Place_of_Operation')}},
	{{validate_Acpt_len_2('Place_Of_Origin')}},
	{{validate_Future_Date('Doc_Expiry_Dte')}},
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('Incorporation_Dte')}},
	{{validate_NoFutureDate('Dte_of_Birth')}},
	{{validate_GenderCode('Gender_Code')}},
	{{validate_CountryCode('Home_Country_Code')}},
	{{validate_IndustryCode('Industry_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_MaritalStatus('Marital_Status')}},
	{{validate_OccupCode('Occup_Code')}},
	{{validate_NoFutureDate('Party_Start_Dte')}},
	{{validate_CountryCode('Nationality')}}
FROM CTE_2
),
{{ full_valid_flag([__NoFutureDate_valid_Batch_Dte',__Acpt_len_8_valid_Party_Intl_Nbr',__Acpt_A_U_valid_Chng_Ind',__Acpt_value_Y_space_valid_Staff_Ind',__Party_Type_Desc_valid_Party_Type_Desc',__Acpt_len_2_valid_Place_of_Operation',__Acpt_len_2_valid_Place_Of_Origin',__Future_Date_valid_Doc_Expiry_Dte',__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_Incorporation_Dte',__NoFutureDate_valid_Dte_of_Birth',__GenderCode_valid_Gender_Code',__CountryCode_valid_Home_Country_Code',__IndustryCode_valid_Industry_Code',__CountryCode_valid_Issue_Country_Code',__MaritalStatus_valid_Marital_Status',__OccupCode_valid_Occup_Code',__NoFutureDate_valid_Party_Start_Dte',__CountryCode_valid_Nationality']) }}
FROM CTE_3)