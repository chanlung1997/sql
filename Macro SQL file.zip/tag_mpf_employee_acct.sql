CTE_3 AS (
	SELECT
	*,
	{{validate_Future_Date('First_Aprov_Dte')}},
	{{validate_NoFutureDate('Employment_Dte')}},
	{{validate_IndustryCode('Industry_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__Future_Date_valid_First_Aprov_Dte',__NoFutureDate_valid_Employment_Dte',__IndustryCode_valid_Industry_Code']) }}
FROM CTE_3)