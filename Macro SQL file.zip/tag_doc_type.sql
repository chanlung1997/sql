CTE_3 AS (
	SELECT
	*,
	{{validate_Doc_Type_Desc('Doc_Type_Desc')}}
FROM CTE_2
),
{{ full_valid_flag([__Doc_Type_Desc_valid_Doc_Type_Desc']) }}
FROM CTE_3)