CTE_3 AS (
	SELECT
	*,
	{{validate_IndustryCode('Industry_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__IndustryCode_valid_Industry_Code']) }}
FROM CTE_3)