CTE_3 AS (
	SELECT
	*,
	{{validate_HKID('Doc_Nbr')}},
	{{validate_DocTypeCode('Doc_Type_Code')}},
	{{validate_NoFutureDate('Dte_Of_Birth')}},
	{{validate_GenderCode('Gender_Code')}},
	{{validate_CountryCode('Home_Country_Code')}},
	{{validate_CountryCode('Issue_Country_Code')}},
	{{validate_MaritalStatus('Marital_Status')}},
	{{validate_TitleCode('Title_Code')}}
FROM CTE_2
),
{{ full_valid_flag([__HKID_valid_Doc_Nbr',__DocTypeCode_valid_Doc_Type_Code',__NoFutureDate_valid_Dte_Of_Birth',__GenderCode_valid_Gender_Code',__CountryCode_valid_Home_Country_Code',__CountryCode_valid_Issue_Country_Code',__MaritalStatus_valid_Marital_Status',__TitleCode_valid_Title_Code']) }}
FROM CTE_3)